import math
DEG_TO_RAD = math.pi / 180.0
RAD_TO_DEG = 180.0 / math.pi
