"""CPU wall timings and bounded, deferred CUDA event timings."""
from contextlib import contextmanager
import json
import time
from pathlib import Path
import torch


class Timer:
    def __init__(self, device, mode="events", max_events=8192):
        self.device = torch.device(device)
        self.mode, self.max_events = mode, max_events
        self.started = time.perf_counter()
        self.rows, self.pending = {}, []
        self.flush_wait_seconds = 0.0
        self.event_flushes = 0

    @contextmanager
    def section(self, name, gpu=True):
        if self.mode == "off":
            yield
            return
        events = self.device.type == "cuda" and self.mode == "events" and gpu
        if events and len(self.pending) >= self.max_events:
            self.flush()
        begin = time.perf_counter()
        if events:
            a, b = torch.cuda.Event(enable_timing=True), torch.cuda.Event(enable_timing=True)
            a.record(torch.cuda.current_stream(self.device))
        try:
            yield
        finally:
            elapsed = time.perf_counter() - begin
            row = self.rows.setdefault(name, {"calls":0,"host_seconds":0.0,"host_max_seconds":0.0,"cuda_seconds":None,"cuda_max_seconds":None})
            row["calls"] += 1
            row["host_seconds"] += elapsed
            row["host_max_seconds"] = max(row["host_max_seconds"],elapsed)
            if events:
                b.record(torch.cuda.current_stream(self.device))
                self.pending.append((name,a,b))

    def flush(self):
        if not self.pending:
            return
        start = time.perf_counter()
        self.pending[-1][2].synchronize()
        self.flush_wait_seconds += time.perf_counter()-start
        self.event_flushes += 1
        for name,a,b in self.pending:
            elapsed = a.elapsed_time(b)/1000
            row = self.rows[name]
            row["cuda_seconds"] = (row["cuda_seconds"] or 0)+elapsed
            row["cuda_max_seconds"] = max(row["cuda_max_seconds"] or 0,elapsed)
        self.pending.clear()

    def report(self):
        self.flush()
        return {"mode":self.mode,"device":str(self.device),"elapsed_wall_seconds":time.perf_counter()-self.started,
                "event_flushes":self.event_flushes,"event_flush_wait_seconds":self.flush_wait_seconds,
                "notes":"Sections can be nested: do not sum them as total time. CUDA events measure stream elapsed time; host_seconds includes enqueue and any waits. wall mode does not synchronize GPU stages.",
                "sections":self.rows}

    def write(self, directory):
        report = self.report()
        Path(directory,"timing.json").write_text(json.dumps(report,indent=2),encoding="utf-8")
        with Path(directory,"timing.tsv").open("w",encoding="utf-8") as out:
            out.write("stage\tcalls\thost_seconds\tcuda_seconds\thost_max_seconds\tcuda_max_seconds\n")
            for name,row in self.rows.items():
                out.write(name+"\t"+"\t".join("" if row[k] is None else str(row[k]) for k in ("calls","host_seconds","cuda_seconds","host_max_seconds","cuda_max_seconds"))+"\n")
        return report
