"""cisTEM-style global greedy peaks, independently implemented using a spatial index.

Reference rule: homurachan/cistem2dtm_pytorch, statistics.py::peak_pick.
Descending score (flat-index tie break), then inclusive circular suppression.
The theoretical Gaussian threshold is applied to GisSPA z-scores; score scaling
and candidate generation remain those of GisSPA.
"""
from contextlib import nullcontext
import math
import numpy as np


class MatchPicks(list):
    """Legacy candidates with automatic-threshold and best-map side outputs."""

def cistem_theoretical_threshold(number_of_valid_search_pixels, number_searched,
                                 expected_false_positives=1.0,
                                 independent_fraction=1.0):
    """cisTEM Gaussian-tail formula, solved without scipy or 1-p cancellation."""
    import math
    for name, value in (("number_of_valid_search_pixels", number_of_valid_search_pixels),
                        ("number_searched", number_searched)):
        if isinstance(value, bool) or not isinstance(value, int) or value <= 0:
            raise ValueError(f"{name} must be a positive integer")
    lam, fraction = float(expected_false_positives), float(independent_fraction)
    if not math.isfinite(lam) or lam <= 0:
        raise ValueError("expected_false_positives must be finite and positive")
    if not math.isfinite(fraction) or not 0 < fraction <= 1:
        raise ValueError("independent_fraction must be in (0, 1]")
    effective = float(number_of_valid_search_pixels) * number_searched * fraction
    if not math.isfinite(effective):
        raise ValueError("effective search count is not finite")
    probability = lam / effective
    if not 0 < probability < 1:
        raise ValueError("expected_false_positives / effective search count must be in (0, 1)")
    low, high = -40.0, 40.0
    for _ in range(100):
        middle = (low + high) / 2.0
        if 0.5 * math.erfc(middle / math.sqrt(2.0)) > probability:
            low = middle
        else:
            high = middle
    return (low + high) / 2.0


def automatic_threshold_info(number_pixels, number_searched, *,
                             expected_false_positives=1.0, independent_fraction=1.0):
    """Shared per-image model, independent of manual cutoffs and Top-M size."""
    threshold = cistem_theoretical_threshold(
        number_pixels, number_searched, expected_false_positives, independent_fraction)
    return dict(
        threshold=threshold, threshold_source='cistem_gaussian_theoretical',
        number_of_valid_search_pixels=number_pixels, number_searched=number_searched,
        expected_false_positives=float(expected_false_positives),
        independent_fraction=float(independent_fraction),
        effective_trials=number_pixels * number_searched * float(independent_fraction),
        threshold_scope='per micrograph; Gaussian-model expectation, not measured error rate')


def split_threshold_candidates(candidates, manual_threshold, auto_info):
    """Split peaks collected at min(manual, automatic), preserving source order.

    Matching scores are float32 in both search modes. Round scalar cutoffs as
    the original NumPy/PyTorch comparisons do before comparing transported
    float64 rows or Python floats, including scores exactly on the cutoff.
    """
    from .topk import CandidateTable

    def select(threshold):
        cutoff = float(np.float32(threshold))
        if isinstance(candidates, CandidateTable):
            return candidates.take(candidates.rows[:, 3] >= cutoff)
        return MatchPicks(p for p in candidates if p.score >= cutoff)

    manual = select(manual_threshold)
    manual.auto_candidates = select(auto_info['threshold'])
    manual.auto_threshold_info = dict(auto_info)
    return manual


def greedy_peak_indices(score,threshold,radius,maximum):
    """Equivalent to repeated argmax/circular suppression on a finite 2-D map.

    Sorted eligible pixels avoid repeated full-image reductions. Grid bins hold
    accepted peaks, so suppressed pixels cannot themselves suppress later peaks.
    """
    score = np.asarray(score)
    if score.ndim != 2 or not np.isfinite(score).all():
        raise ValueError('peak score map must be finite and two-dimensional')
    if not math.isfinite(threshold) or not math.isfinite(radius) or radius < 0:
        raise ValueError('peak threshold/radius must be finite; radius must be nonnegative')
    if isinstance(maximum,bool) or not isinstance(maximum,int) or maximum < 0:
        raise ValueError('maximum must be a nonnegative integer')
    eligible = np.flatnonzero(score.reshape(-1) >= threshold)
    if not maximum or not len(eligible):
        return np.empty(0,dtype=np.int64),len(eligible)
    order = np.argsort(-score.reshape(-1)[eligible],kind='stable')
    ordered = eligible[order]
    if radius == 0:
        return ordered[:maximum],len(eligible)
    cell = max(1.0,radius)
    radius2 = radius*radius
    width = score.shape[1]
    bins,kept = {},[]
    for flat in ordered:
        y,x = divmod(int(flat),width)
        by,bx = math.floor(y/cell),math.floor(x/cell)
        blocked = False
        for iy in range(by-1,by+2):
            for ix in range(bx-1,bx+2):
                if any((y-py)**2+(x-px)**2 <= radius2 for py,px in bins.get((iy,ix),())):
                    blocked = True
                    break
            if blocked:
                break
        if blocked:
            continue
        kept.append(int(flat))
        bins.setdefault((by,bx),[]).append((y,x))
        if len(kept) == maximum:
            break
    return np.asarray(kept,dtype=np.int64),len(eligible)

def peaks_from_maps(maps, cfg, record, timer=None, *,
                    expected_false_positives=1.0, independent_fraction=1.0):
    """Extra peaks only: null threshold now selects a per-micrograph Gaussian cutoff.

    Keyword defaults above are the model controls. They are deliberately NOT
    new Config fields; existing JSON validation and callers remain unchanged.
    """
    from .engine import Pick, read_views
    with timer.section('peaks.cistem_threshold', gpu=False) if timer else nullcontext():
        number_pixels = int(maps['score'].size)  # original image, no artificial padding
        views, psi = read_views(cfg)
        number_searched = len(views) * len(psi)  # ALL poses, not M or surviving poses
        automatic = cfg.cistem_peak_threshold is None
        if automatic:
            threshold = automatic_threshold_info(
                number_pixels, number_searched,
                expected_false_positives=expected_false_positives,
                independent_fraction=independent_fraction)['threshold']
        else:
            threshold = float(cfg.cistem_peak_threshold)
        radius = cfg.cistem_peak_radius_angstrom / record.pixel_size

    with timer.section('peaks.cistem_greedy', gpu=False) if timer else nullcontext():
        index, eligible = greedy_peak_indices(
            maps['score'], threshold, radius, cfg.cistem_maximum_peaks)
        picks = []
        for flat in index:
            y, x = divmod(int(flat), maps['score'].shape[1])
            picks.append(Pick(x, y, float(maps['rot'][y, x]),
                              float(maps['tilt'][y, x]), float(maps['psi'][y, x]),
                              float(maps['score'][y, x])))
    info = dict(
        method='cistem_global_greedy_circular_suppression',
        score_source='GisSPA best per-pixel z-score',
        threshold=threshold,
        threshold_source='cistem_gaussian_theoretical' if automatic else 'manual_override',
        number_of_valid_search_pixels=number_pixels,
        number_searched=number_searched,
        expected_false_positives=float(expected_false_positives) if automatic else None,
        independent_fraction=float(independent_fraction) if automatic else None,
        effective_trials=number_pixels * number_searched * float(independent_fraction) if automatic else None,
        threshold_scope='per micrograph; Gaussian-model expectation, not measured error rate',
        radius_angstrom=cfg.cistem_peak_radius_angstrom, radius_pixels=radius,
        maximum_peaks=cfg.cistem_maximum_peaks, eligible_pixels=eligible, picks=len(picks),
        stopped_at_limit=bool(cfg.cistem_maximum_peaks and len(picks) == cfg.cistem_maximum_peaks),
        disabled_by_zero_limit=cfg.cistem_maximum_peaks == 0,
        tie_break='smallest flattened pixel index',
        suppression='distance <= radius, independent of orientation',
        reference='https://github.com/homurachan/cistem2dtm_pytorch/blob/main/src/cistem2dtm/statistics.py')
    return picks, info
