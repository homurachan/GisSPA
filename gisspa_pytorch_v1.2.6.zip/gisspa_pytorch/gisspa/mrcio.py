from __future__ import annotations

from pathlib import Path
import mrcfile
import numpy as np


def read_mrc(path, pixel_override=None, *, volume=False, stack=False, image_slice=1):
    path = Path(path)
    if path.suffix.lower() not in (".mrc", ".mrcs", ".map"):
        raise ValueError(f"only MRC/MRCS/MAP data are supported: {path}")
    with mrcfile.open(path, mode="r", permissive=False) as handle:
        axes = tuple(int(getattr(handle.header, k)) for k in ("mapc", "mapr", "maps"))
        if axes != (1, 2, 3):
            raise ValueError(f"MRC axis mapping {axes} is unsupported; reorder to mapc/mapr/maps=1/2/3 first: {path}")
        voxel = [float(handle.voxel_size[k]) for k in ("x", "y", "z")]
        pixel = pixel_override if pixel_override is not None else voxel[0]
        if not np.isfinite(pixel) or pixel <= 0:
            raise ValueError(f"invalid MRC pixel size; supply an explicit pixel size: {path}")
        if pixel_override is None:
            active = voxel if volume else voxel[:2]
            if any(not np.isfinite(v) or v <= 0 or not np.isclose(v, pixel, rtol=1e-4) for v in active):
                raise ValueError(f"anisotropic or invalid voxel sizes {active}: {path}")
        data = np.array(handle.data, dtype=np.float32, copy=True, order="C")
    if not np.isfinite(data).all():
        raise ValueError(f"non-finite MRC data: {path}")
    if volume:
        if data.ndim != 3 or len(set(data.shape)) != 1 or data.shape[0] < 4:
            raise ValueError(f"template volume must be cubic, at least 4^3: {data.shape}")
    elif stack:
        if data.ndim == 2:
            data = data[None]
        if data.ndim != 3:
            raise ValueError("template stack must be 2-D or 3-D")
    else:
        if image_slice < 1:
            raise ValueError("image_slice is 1-based")
        if data.ndim == 3:
            if image_slice > data.shape[0]:
                raise ValueError(f"image_slice exceeds stack depth: {path}")
            data = data[image_slice - 1]
        elif data.ndim != 2 or image_slice != 1:
            raise ValueError(f"expected a 2-D image or a valid stack slice: {path}")
    return data, float(pixel)


def write_mrc(path, data, pixel, *, stack=False):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    if hasattr(data, "detach"):
        data = data.detach().cpu().numpy()
    with mrcfile.new(path, overwrite=True) as handle:
        handle.set_data(np.asarray(data, dtype=np.float32))
        handle.voxel_size = float(pixel)
        if stack:
            handle.set_image_stack()
        handle.update_header_stats()
    return path
