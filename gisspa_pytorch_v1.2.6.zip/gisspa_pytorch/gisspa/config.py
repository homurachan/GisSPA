from __future__ import annotations

import json
import math
from dataclasses import asdict, dataclass, fields
from pathlib import Path


@dataclass
class Config:
    input_star: str | None = None
    input_lst: str | None = None
    input_mrc: str | None = None
    template_mrc: str | None = None
    template_stack: str | None = None
    orientations_file: str | None = None
    output_dir: str = "results"
    micrograph_root: str | None = None
    pixel_size: float | None = None
    template_pixel_size: float | None = None
    voltage: float = 300.0
    cs: float = 2.7
    amplitude_contrast: float = 0.07
    defocus_u: float | None = None
    defocus_v: float | None = None
    defocus_angle: float = 0.0
    phase_shift: float = 0.0
    image_slice: int = 1
    symmetry: str = "C1"
    angular_step: float = 5.0
    psi_step: float = 5.0
    projection_size: int | None = None
    window_size: int = 320
    overlap: int | None = None
    diameter: float = 100.0
    high_resolution: float = 8.0
    low_resolution: float = 300.0
    kk: float = 3.0
    a: float = -9.32
    b: float = 2.65
    b2: float = 0.01908
    bfactor: float = -78.7757
    bfactor2: float = -12.9121
    bfactor3: float = 1.28732
    phase_flip: bool = False
    invert: bool = False
    threshold: float = 7.0
    norm_type: int = 1
    orientation_batch_size: int = 8
    tile_group_size: int = 0
    template_cache: str = "auto"
    candidate_buffer_mb: int = 16
    statistics_precision: str = "mixed"
    score_processing: str = "contiguous"
    cache_template_conjugate: bool = True
    topk_detailed_timing: bool = True
    topk_skip_unchanged: bool = False
    inverse_fft_detailed_timing: bool = True
    fft_profile_calls: int = 0
    cistem_peak_picking: bool = True
    cistem_peak_threshold: float | None = None
    cistem_peak_radius_angstrom: float = 10.0
    cistem_maximum_peaks: int = 1000
    search_mode: str = "topk"
    boundary_mode: str = "micrograph"
    top_m: int = 16
    fft_size_mode: str = "cistem-standard"
    padding_mode: str = "noise"
    image_padding: int | None = None
    padding_seed: int = 0
    timing: str = "events"
    timing_max_events: int = 8192
    dedup_mode: str = "pose"
    dedup_use_symmetry: bool = False
    dedup_batch_size: int = 128
    dedup_chunk_size: int = 4096
    device: str = "auto"
    gpu_ids: list[int] | None = None
    worker_startup_timeout: float = 180.0
    cpu_threads: int = 4
    first: int = 0
    last: int | None = None
    deduplicate: bool = True
    dedup_distance: float | None = None
    dedup_angle: float = 15.0
    dedup_allow_180: bool = False
    write_lst: bool = False
    write_maps: bool = True
    extract_box_size: int | None = None
    overwrite: bool = False

    def validate(self) -> None:
        if self.gpu_ids is not None:
            if (not isinstance(self.gpu_ids,list) or not self.gpu_ids or
                any(isinstance(x,bool) or not isinstance(x,int) or x < 0 for x in self.gpu_ids) or
                len(set(self.gpu_ids)) != len(self.gpu_ids)):
                raise ValueError("gpu_ids must be null or a nonempty list of distinct nonnegative CUDA indices")
            if self.device == "cpu":
                raise ValueError("gpu_ids cannot be combined with device=cpu")
        if isinstance(self.worker_startup_timeout,bool) or not isinstance(self.worker_startup_timeout,(int,float)) or not math.isfinite(self.worker_startup_timeout) or self.worker_startup_timeout <= 0:
            raise ValueError("worker_startup_timeout must be finite and positive")
        for name, choices in (("search_mode", ("topk", "legacy")), ("fft_size_mode", ("cistem-standard", "power2", "exact")),
                              ("boundary_mode", ("micrograph", "template_halo")),
                              ("score_processing", ("contiguous", "contiguous_scratch", "direct")),
                              ("padding_mode", ("noise", "zero", "replicate")), ("timing", ("events", "wall", "off")),
                              ("dedup_mode", ("pose", "spatial", "legacy"))):
            if getattr(self, name) not in choices:
                raise ValueError(f"{name} must be one of {choices}")
        for name in ("top_m", "timing_max_events", "dedup_batch_size", "dedup_chunk_size"):
            if isinstance(getattr(self, name), bool) or not isinstance(getattr(self, name), int) or getattr(self, name) < 1:
                raise ValueError(f"{name} must be a positive integer")
        if isinstance(self.padding_seed, bool) or not isinstance(self.padding_seed, int) or self.padding_seed < 0:
            raise ValueError("padding_seed must be a nonnegative integer")
        min_padding = self.window_size // 2 if self.boundary_mode == "template_halo" else 0
        if self.image_padding is not None and (isinstance(self.image_padding, bool) or not isinstance(self.image_padding, int)
                                                or self.image_padding < min_padding):
            raise ValueError(f"image_padding must be null or an integer >= {min_padding}")
        for name in ("fft_profile_calls", "cistem_maximum_peaks"):
            value = getattr(self,name)
            if isinstance(value,bool) or not isinstance(value,int) or value < 0:
                raise ValueError(f"{name} must be a nonnegative integer")
        if isinstance(self.cistem_peak_radius_angstrom,bool) or not isinstance(self.cistem_peak_radius_angstrom,(int,float)) or not math.isfinite(self.cistem_peak_radius_angstrom) or self.cistem_peak_radius_angstrom < 0:
            raise ValueError("cistem_peak_radius_angstrom must be finite and nonnegative")
        if self.cistem_peak_threshold is not None and (isinstance(self.cistem_peak_threshold,bool) or not isinstance(self.cistem_peak_threshold,(int,float)) or not math.isfinite(self.cistem_peak_threshold)):
            raise ValueError("cistem_peak_threshold must be null or finite")
        if self.template_cache not in ("auto", "device", "mmap"):
            raise ValueError("template_cache must be auto, device or mmap")
        if self.statistics_precision not in ("mixed", "float64"):
            raise ValueError("statistics_precision must be mixed or float64")
        if isinstance(self.tile_group_size, bool) or not isinstance(self.tile_group_size, int) or self.tile_group_size < 0:
            raise ValueError("tile_group_size must be 0 (automatic) or a positive integer")
        if isinstance(self.candidate_buffer_mb, bool) or not isinstance(self.candidate_buffer_mb, int) or self.candidate_buffer_mb < 1:
            raise ValueError("candidate_buffer_mb must be a positive integer")
        if sum(x is not None for x in (self.input_star, self.input_lst, self.input_mrc)) != 1:
            raise ValueError("provide exactly one of input_star, input_lst, input_mrc")
        if sum(x is not None for x in (self.template_mrc, self.template_stack)) != 1:
            raise ValueError("provide exactly one of template_mrc (3-D) and template_stack (2-D bank)")
        if self.template_stack and not self.orientations_file:
            raise ValueError("template_stack requires orientations_file (cisTEM phi theta per row)")
        if self.norm_type != 1:
            raise ValueError("this port supports norm_type=1 only")
        for name in ("angular_step", "psi_step", "diameter", "high_resolution", "low_resolution", "voltage"):
            value = getattr(self, name)
            if not math.isfinite(value) or value <= 0:
                raise ValueError(f"{name} must be finite and positive")
        if not 0 < self.psi_step <= 360 or not 0 < self.angular_step <= 90:
            raise ValueError("psi_step must be in (0,360], angular_step in (0,90]")
        if self.high_resolution > self.low_resolution:
            raise ValueError("high_resolution must be <= low_resolution (Angstrom)")
        if not 0 <= self.amplitude_contrast < 1 or self.kk < 0 or self.cs < 0:
            raise ValueError("invalid amplitude_contrast, kk or cs")
        for name in ("pixel_size", "template_pixel_size"):
            value = getattr(self, name)
            if value is not None and (not math.isfinite(value) or value <= 0):
                raise ValueError(f"{name} must be positive")
        for name in ("window_size", "orientation_batch_size", "cpu_threads", "image_slice"):
            value = getattr(self, name)
            if isinstance(value, bool) or not isinstance(value, int) or value < 1:
                raise ValueError(f"{name} must be a positive integer")
        if self.window_size < 32 or self.window_size % 32:
            raise ValueError("window_size must be a multiple of 32 (original 1024-element peak groups)")
        if self.diameter >= self.window_size:
            raise ValueError("diameter in pixels must be smaller than window_size")
        if self.overlap is None:
            self.overlap = int(self.diameter)
        if not isinstance(self.overlap, int) or not 0 <= self.overlap < self.window_size:
            raise ValueError("overlap must be an integer in [0, window_size)")
        if self.first < 0 or (self.last is not None and self.last < self.first):
            raise ValueError("invalid first/last range (last is exclusive)")
        for name in ("projection_size", "extract_box_size"):
            value = getattr(self, name)
            if value is not None and (not isinstance(value, int) or value < 2):
                raise ValueError(f"{name} must be an integer >= 2")
        if self.dedup_distance is not None and self.dedup_distance <= 0:
            raise ValueError("dedup_distance must be positive")
        if not 0 <= self.dedup_angle <= 180:
            raise ValueError("dedup_angle must be in [0,180]")
        for field in fields(self):
            value = getattr(self, field.name)
            if isinstance(value, float) and not math.isfinite(value):
                raise ValueError(f"{field.name} must be finite")
        for name in ("phase_flip", "invert", "deduplicate", "dedup_allow_180", "dedup_use_symmetry", "write_lst", "write_maps", "overwrite",
                     "cache_template_conjugate", "topk_detailed_timing", "topk_skip_unchanged", "inverse_fft_detailed_timing", "cistem_peak_picking"):
            if not isinstance(getattr(self, name), bool):
                raise ValueError(f"{name} must be a JSON boolean")
        if self.dedup_use_symmetry and self.symmetry.strip().upper()[0] not in ("C","D"):
            raise ValueError("dedup_use_symmetry currently supports Cn and Dn only; disable it for T/O/I")

    def to_dict(self) -> dict:
        return asdict(self)


def load_config(path: str | Path) -> Config:
    path = Path(path).resolve()
    data = json.loads(path.read_text(encoding="utf-8-sig"))
    if not isinstance(data, dict):
        raise ValueError("configuration must be a JSON object")
    allowed = {f.name for f in fields(Config)}
    unknown = set(data) - allowed
    if unknown:
        raise ValueError(f"unknown configuration fields: {', '.join(sorted(unknown))}")
    for key in ("input_star", "input_lst", "input_mrc", "template_mrc", "template_stack",
                "orientations_file", "output_dir", "micrograph_root"):
        if data.get(key) is not None:
            p = Path(data[key]).expanduser()
            data[key] = str((path.parent / p).resolve() if not p.is_absolute() else p.resolve())
    data.setdefault("output_dir", str(path.parent / "results"))
    cfg = Config(**data)
    cfg.validate()
    return cfg
