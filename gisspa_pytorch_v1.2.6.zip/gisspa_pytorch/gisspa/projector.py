"""Fourier geometry adapted from cistem2dtm_pytorch, pure PyTorch gather.

Matrices map a 2-D sampling plane into the 3-D reference: Rz(phi)Ry(theta)Rz(psi).
The 2-D rotator uses the same plane convention after GisSPA preprocessing.
"""
from __future__ import annotations

import math
import torch


def enforce_x0(spectrum):
    n = spectrum.shape[-2]
    pos = torch.arange(1, (n - 1) // 2 + 1, device=spectrum.device)
    spectrum[..., n - pos, 0] = spectrum[..., pos, 0].conj()
    return spectrum


def half_plane(n, device, dtype=torch.float32):
    y = torch.fft.fftfreq(n, device=device, dtype=dtype) * n
    x = torch.arange(n // 2 + 1, device=device, dtype=dtype)
    yy, xx = torch.meshgrid(y, x, indexing="ij")
    return torch.stack((xx, yy, torch.zeros_like(xx)), dim=0)


class FourierProjector:
    def __init__(self, volume):
        if volume.ndim != 3 or len(set(volume.shape)) != 1:
            raise ValueError("FourierProjector requires a cubic volume")
        self.n = volume.shape[-1]
        self.spectrum = torch.fft.rfftn(torch.fft.ifftshift(volume), norm="forward")

    def sample(self, coordinates):
        n = self.n
        q = n // 2 + 1
        lower, upper = -(n // 2), (n - 1) // 2
        x, y, z = coordinates.unbind(1)
        negative = x < 0
        i0, j0, k0 = [torch.floor(v).long() for v in (x, y, z)]
        valid = ((((~negative) & (i0 + 1 <= n // 2)) | (negative & (i0 >= -(n // 2))))
                 & (j0 >= lower) & (j0 + 1 <= upper) & (k0 >= lower) & (k0 + 1 <= upper))
        flat = self.spectrum.flatten()
        result = torch.zeros_like(x, dtype=self.spectrum.dtype)
        for dz in (0, 1):
            kk = k0 + dz
            wz = 1 - (z - kk).abs()
            for dy in (0, 1):
                jj = j0 + dy
                wy = 1 - (y - jj).abs()
                for dx in (0, 1):
                    ii = i0 + dx
                    wx = 1 - (x - ii).abs()
                    xi = torch.where(negative, -ii, ii).clamp(0, q - 1)
                    yi = torch.where(negative, -jj, jj).remainder(n)
                    zi = torch.where(negative, -kk, kk).remainder(n)
                    value = flat[(zi * n + yi) * q + xi]
                    value = torch.where(negative, value.conj(), value)
                    result = result + value * wx * wy * wz
        result = torch.where(valid, result, 0)
        enforce_x0(result)
        result[..., 0, 0] = 0
        return result

    def project(self, matrices, size=None, template_pixel=1.0, image_pixel=1.0):
        size = int(size or self.n)
        if matrices.ndim == 2:
            matrices = matrices[None]
        base = half_plane(size, matrices.device, matrices.dtype)
        coords = torch.einsum("bij,jhw->bihw", matrices, base)
        coords = coords * (self.n / size * template_pixel / image_pixel)
        spectrum = self.sample(coords)
        real = torch.fft.irfft2(spectrum, s=(size, size), norm="forward")
        return torch.fft.fftshift(real, dim=(-2, -1))


def rotate_fourier(images, psi_deg):
    """Rotate centered processed templates using the cisTEM in-plane sampling map.

    Positive psi uses input coordinates (cos*p_x-sin*p_y, sin*p_x+cos*p_y).
    This equals changing psi in Rz(phi)Ry(theta)Rz(psi); no legacy sign offsets.
    """
    if float(psi_deg) % 360 == 0:
        return images.clone()
    n = images.shape[-1]
    if images.shape[-2] != n:
        raise ValueError("in-plane rotation expects square templates")
    spectra = torch.fft.rfft2(torch.fft.ifftshift(images, dim=(-2, -1)), norm="forward")
    plane = half_plane(n, images.device, images.dtype)
    a = math.radians(float(psi_deg))
    x = math.cos(a) * plane[0] - math.sin(a) * plane[1]
    y = math.sin(a) * plane[0] + math.cos(a) * plane[1]
    negative = x < 0
    i0, j0 = torch.floor(x).long(), torch.floor(y).long()
    valid = ((((~negative) & (i0 + 1 <= n // 2)) | (negative & (i0 >= -(n // 2))))
             & (j0 >= -(n // 2)) & (j0 + 1 <= (n - 1) // 2))
    result = torch.zeros_like(spectra)
    q = n // 2 + 1
    flat = spectra.flatten(-2)
    for dy in (0, 1):
        jj = j0 + dy
        for dx in (0, 1):
            ii = i0 + dx
            weight = (1 - (x - ii).abs()) * (1 - (y - jj).abs())
            xi = torch.where(negative, -ii, ii).clamp(0, q - 1)
            yi = torch.where(negative, -jj, jj).remainder(n)
            value = flat[:, (yi * q + xi).flatten()].reshape_as(result)
            result += torch.where(negative, value.conj(), value) * weight
    result = torch.where(valid, result, 0)
    enforce_x0(result)
    result[..., 0, 0] = 0
    return torch.fft.fftshift(torch.fft.irfft2(result, s=(n, n), norm="forward"), dim=(-2, -1))


def matrix_to_relion(matrix):
    """Decompose cisTEM sampling R; RELION's Euler matrix is R.T.

    Returns Rot/Tilt/Psi in degrees, Tilt in [0,180], handling both poles.
    """
    r = torch.as_tensor(matrix, dtype=torch.float64)
    theta = torch.atan2(torch.hypot(r[..., 0, 2], r[..., 1, 2]), r[..., 2, 2])
    phi = torch.atan2(r[..., 1, 2], r[..., 0, 2])
    psi = torch.atan2(r[..., 2, 1], -r[..., 2, 0])
    pole = torch.sin(theta).abs() < 1e-10
    south = r[..., 2, 2] < 0
    pole_psi = torch.where(south, torch.atan2(r[..., 1, 0], -r[..., 0, 0]),
                           torch.atan2(r[..., 1, 0], r[..., 0, 0]))
    # At theta=pi, Rz(0)Ry(pi)Rz(psi) has R10=sin(psi).
    phi = torch.where(pole, 0, phi)
    psi = torch.where(pole, pole_psi, psi)
    out = torch.stack((phi, theta, psi), -1) * (180 / math.pi)
    out[..., 0] = (out[..., 0] + 180) % 360 - 180
    out[..., 2] = (out[..., 2] + 180) % 360 - 180
    return out


def legacy_lst_matrix(alt_deg, az_deg, inplane_deg):
    """Boundary-only interpretation of old EMAN-format LST, by axis matrices.

    New matching uses only cisTEM angles. This is not used by the matcher.
    """
    alt, az, psi = map(math.radians, (alt_deg, az_deg, inplane_deg))
    def rz(a):
        return torch.tensor([[math.cos(a), -math.sin(a), 0],
                             [math.sin(a), math.cos(a), 0], [0, 0, 1]], dtype=torch.float64)
    rx = torch.tensor([[1, 0, 0], [0, math.cos(alt), -math.sin(alt)],
                       [0, math.sin(alt), math.cos(alt)]], dtype=torch.float64)
    return rz(az) @ rx @ rz(psi)
