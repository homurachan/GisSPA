"""Bounded caches, reusable rotation plans, and batched candidate transfer."""
from __future__ import annotations

import math
from pathlib import Path

import numpy as np
import torch

from .filters import mask_and_normalize, template_mask
from .projector import half_plane, enforce_x0


def available_device_bytes(device):
    if device.type != "cuda":
        return 1024 ** 3  # Conservative automatic CPU working-set budget.
    free, _ = torch.cuda.mem_get_info(device)
    reusable = torch.cuda.memory_reserved(device) - torch.cuda.memory_allocated(device)
    return int(free + reusable)


def tile_group_count(cfg, device, total):
    if cfg.tile_group_size:
        return min(total, cfg.tile_group_size)
    # Per-tile FFT, moments/mean/std, winning values/indices and transition
    # temporaries. Reserve most memory for the template batch + FFT workspace.
    per_tile = cfg.window_size ** 2 * (64 if cfg.statistics_precision == "float64" else 48)
    allowed = int(available_device_bytes(device) * 0.3)
    return max(1, min(total, allowed // per_tile))


def use_device_bank(required,cfg,device):
    reserve = cfg.orientation_batch_size*cfg.window_size**2*64+256*1024**2
    return cfg.template_cache == "device" or (
        cfg.template_cache == "auto" and device.type == "cuda"
        and required+reserve < available_device_bytes(device)*0.65)


class SpectrumBank:
    def __init__(self, path, cfg, device, log):
        self.device = device
        self.tensor = None
        self.array = None
        self.loads = 0
        if isinstance(path,torch.Tensor):
            self.tensor = path
            required = path.numel()*path.element_size()
            self.mode,self.build_storage = "device","direct_device"
        else:
            # Cache selection now precedes generation. A disk source stays mmap,
            # including auto OOM fallback; do not upload it again opportunistically.
            self.array = np.load(path,mmap_mode="r+")
            required = self.array.nbytes
            self.mode,self.build_storage = "mmap","mmap"
        log(f"Base spectrum cache: {self.mode}; {required / 1024**3:.3f} GiB")

    def get(self, start, stop):
        self.loads += 1
        if self.tensor is not None:
            return self.tensor[start:stop]
        source = torch.from_numpy(self.array[start:stop])
        if self.device.type == "cuda":
            # A pinned source lets the CPU enqueue the transfer without a
            # stream-wide synchronization. Its allocator tracks transfer use.
            return source.pin_memory().to(self.device, non_blocking=True)
        return source

    def close(self):
        self.tensor = None
        if self.array is not None:
            self.array._mmap.close()
            self.array = None


class TemplateRotator:
    """One live Psi plan and one spatial mask; never cache every angle."""
    def __init__(self, n, cfg, device):
        self.n, self.cfg, self.device = n, cfg, device
        self.plane = half_plane(n, device)
        self.mask = template_mask(n, cfg, device)
        self.psi = None
        self.corners = []
        self.negative = self.valid = None
        self.plan_builds = 0
        self.prepared_batches = 0

    def set_angle(self, psi):
        if self.psi == psi:
            return
        self.psi = psi
        self.corners = []
        self.negative = self.valid = None
        self.plan_builds += 1
        if float(psi) % 360 == 0:
            return
        n, q = self.n, self.n // 2 + 1
        a = math.radians(float(psi))
        x = math.cos(a)*self.plane[0] - math.sin(a)*self.plane[1]
        y = math.sin(a)*self.plane[0] + math.cos(a)*self.plane[1]
        negative = x < 0
        i0, j0 = torch.floor(x).long(), torch.floor(y).long()
        self.negative = negative
        self.valid = ((((~negative) & (i0+1 <= n//2)) | (negative & (i0 >= -(n//2))))
                      & (j0 >= -(n//2)) & (j0+1 <= (n-1)//2))
        for dy in (0, 1):
            jj = j0 + dy
            for dx in (0, 1):
                ii = i0 + dx
                weight = (1-(x-ii).abs())*(1-(y-jj).abs())
                xi = torch.where(negative, -ii, ii).clamp(0,q-1)
                yi = torch.where(negative, -jj, jj).remainder(n)
                self.corners.append(((yi*q+xi).flatten(), weight))

    def real_from_spectrum(self, spectrum):
        if self.psi is None:
            raise RuntimeError("rotation angle has not been set")
        if not self.corners:
            result = spectrum
        else:
            result = torch.zeros_like(spectrum)
            flat = spectrum.flatten(-2)
            for index, weight in self.corners:
                value = flat.index_select(1,index).reshape_as(result)
                result.add_(torch.where(self.negative, value.conj(), value)*weight)
            result.masked_fill_(~self.valid,0)
            enforce_x0(result)
            result[...,0,0] = 0
        real = torch.fft.irfft2(result,s=(self.n,self.n),norm="forward")
        return torch.fft.fftshift(real,dim=(-2,-1))

    def prepare(self, spectrum, fft_size=None, timer=None):
        from contextlib import nullcontext
        from .filters import center_pad
        self.prepared_batches += 1
        with timer.section("template.rotation_inverse_fft") if timer else nullcontext():
            real = self.real_from_spectrum(spectrum)
        with timer.section("template.mask_normalize") if timer else nullcontext():
            normalized = mask_and_normalize(real,self.cfg,self.mask)
        with timer.section("template.pad_forward_fft") if timer else nullcontext():
            if fft_size is not None and fft_size != self.n:
                normalized = center_pad(normalized,fft_size)
            return torch.fft.rfft2(normalized,norm="forward")


class CandidateBuffer:
    """Transfer dense, small peak arrays in chunks; select rows on the CPU.

    This avoids CUDA nonzero (dynamic output size) and per-template .tolist()
    synchronizations. Locations stay int64: large images do not lose precision.
    """
    def __init__(self, cfg, views, offsets, shape, output, pick_type, threshold=None):
        self.cfg, self.views, self.offsets, self.shape = cfg, views, offsets, shape
        self.threshold = cfg.threshold if threshold is None else threshold
        self.output, self.pick_type = output, pick_type
        self.pending = []
        self.bytes = 0
        self.flushes = 0

    def add(self, peaks, positions, tile_id, view_start, psi):
        self.pending.append((peaks,positions,tile_id,view_start,psi))
        self.bytes += peaks.numel()*peaks.element_size()+positions.numel()*positions.element_size()
        if self.bytes >= self.cfg.candidate_buffer_mb*1024**2:
            self.flush()

    def flush(self):
        if not self.pending:
            return
        peaks = torch.cat([item[0] for item in self.pending])
        positions = torch.cat([item[1] for item in self.pending])
        if peaks.device.type == "cuda":
            host_values = torch.empty(peaks.shape,dtype=peaks.dtype,device="cpu",pin_memory=True)
            host_positions = torch.empty(positions.shape,dtype=positions.dtype,device="cpu",pin_memory=True)
            host_values.copy_(peaks,non_blocking=True)
            host_positions.copy_(positions,non_blocking=True)
            complete = torch.cuda.Event()
            complete.record(torch.cuda.current_stream(peaks.device))
            complete.synchronize()
        else:
            host_values, host_positions = peaks, positions
        values, indices = host_values.numpy(), host_positions.numpy()
        begin, n = 0, self.cfg.window_size
        h,w = self.shape
        for batch,_,tile_id,view_start,psi in self.pending:
            stop = begin+len(batch)
            scores, loc = values[begin:stop],indices[begin:stop]
            y,x = self.offsets[tile_id]
            cx,cy = x+loc%n,y+loc//n
            good = np.isfinite(scores)&(scores >= self.threshold)&(cx>=0)&(cx<w)&(cy>=0)&(cy<h)
            rows,groups = np.nonzero(good)
            selected = zip(rows.tolist(),cx[rows,groups].tolist(),cy[rows,groups].tolist(),scores[rows,groups].tolist())
            for b,px,py,score in selected:
                phi,theta = self.views[view_start+b]
                self.output.append(self.pick_type(px,py,phi,theta,psi,score,view_start+b,tile_id))
            begin = stop
        self.pending.clear()
        self.bytes = 0
        self.flushes += 1
