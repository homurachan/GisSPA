"""Exact per-pixel raw Top-M, all-orientation moments, sparse candidate reduction."""
import numpy as np
import torch
from contextlib import nullcontext


def topk_stage(timer,detailed,name):
    return timer.section("topk."+name) if timer is not None and detailed else nullcontext()


class TopWorkspace:
    """One reusable scratch area shared by sequential tiles, never one per tile.

    The correlation crop writes straight into the incoming columns. Selection
    reads this buffer before statistics are allowed to square those columns.
    """
    def __init__(self,pixels,m,batch_size,device,precision="mixed",processing="direct",skip_unchanged=False):
        self.pixels,self.m,self.batch_size = pixels,m,batch_size
        self.merged = torch.empty((pixels,m+batch_size),device=device)
        self.index = torch.empty((pixels,m),device=device,dtype=torch.int64)
        self.old_index = torch.empty_like(self.index)
        self.old_ids = torch.empty((pixels,m),device=device,dtype=torch.int32)
        self.is_old = torch.empty((pixels,m),device=device,dtype=torch.bool)
        dtype = torch.float32 if precision == "mixed" else torch.float64
        self.reduction = torch.empty(pixels,device=device,dtype=dtype)
        self.double_values = (torch.empty((pixels,batch_size),device=device,dtype=torch.float64)
                              if precision == "float64" else None)
        # Flat allocations let partial tiles/batches reshape to tightly packed
        # B x P arrays instead of slicing rows with a larger persistent stride.
        self.crop_values = (torch.empty(pixels*batch_size,device=device)
                            if processing != "direct" else None)
        self.square_values = (torch.empty(pixels*batch_size,device=device,dtype=dtype)
                              if processing == "contiguous_scratch" else None)
        self.gate_max = self.gate_min = self.gate_active = None
        self.compact_merge = self.compact_values = self.compact_ids = None
        if skip_unchanged:
            self.gate_max = torch.empty(pixels,device=device)
            self.gate_min = torch.empty_like(self.gate_max)
            self.gate_active = torch.empty(pixels,device=device,dtype=torch.bool)
            self.compact_merge = torch.empty_like(self.merged)
            self.compact_values = torch.empty((pixels,m),device=device)
            self.compact_ids = torch.empty((pixels,m),device=device,dtype=torch.int32)

    def contiguous_scores(self,pixels,batch_size):
        if pixels>self.pixels or batch_size>self.batch_size or self.crop_values is None:
            raise ValueError("contiguous score workspace unavailable or capacity exceeded")
        return self.crop_values[:pixels*batch_size].view(batch_size,pixels)

    def incoming(self,pixels,batch_size):
        if pixels>self.pixels or batch_size>self.batch_size:
            raise ValueError("Top-M workspace capacity exceeded")
        return self.merged[:pixels,self.m:self.m+batch_size]

    @property
    def nbytes(self):
        return sum(t.numel()*t.element_size() for t in vars(self).values() if isinstance(t,torch.Tensor))


class TopScores:
    def __init__(self,shape,m,device):
        self.shape,self.m = shape,m
        self.values = torch.full((shape[0]*shape[1],m),-torch.inf,device=device)
        self.ids = torch.full(self.values.shape,-1,device=device,dtype=torch.int32)
        self.cutoff = torch.full((shape[0]*shape[1],),-torch.inf,device=device)
        self.seen = 0
        self.skip_counts = dict(pixel_updates=0,bounds_checked=0,selected=0,skipped=0,
                                all_skipped_batches=0,partial_batches=0)

    def add(self,cc,pose_ids):
        # Compatibility path for callers with an existing B x H x W batch.
        workspace = TopWorkspace(self.values.shape[0],self.m,len(cc),cc.device)
        workspace.incoming(self.values.shape[0],len(cc)).copy_(cc.reshape(len(cc),-1).T)
        self.select(workspace,pose_ids)

    def select(self,workspace,pose_ids,timer=None,detailed=False,skip_unchanged=False,incoming_scores=None):
        """Select Top-M from packed incoming_scores or prefilled direct columns."""
        pose_ids = pose_ids.to(dtype=torch.int32)
        p,m,b = self.values.shape[0],self.m,len(pose_ids)
        if workspace.m != m:
            raise ValueError("Top-M workspace rank mismatch")
        workspace.incoming(p,b)  # Validate capacity before writing any state.
        if incoming_scores is not None and (incoming_scores.shape != (b,p) or not incoming_scores.is_contiguous()):
            raise ValueError("incoming_scores must be packed B x P")
        source = workspace.incoming(p,b) if incoming_scores is None else incoming_scores.T
        initialized = self.seen >= m
        self.seen += b
        self.skip_counts["pixel_updates"] += p
        active = None
        if skip_unchanged and initialized:
            if workspace.gate_max is None:
                raise ValueError("skip-unchanged needs a gating workspace")
            with topk_stage(timer,detailed,"gate_bounds"):
                # Gate directly on the original crop, BEFORE copying all pixels.
                if incoming_scores is None:
                    torch.amax(source,dim=1,out=workspace.gate_max[:p])
                else:
                    torch.amax(incoming_scores,dim=0,out=workspace.gate_max[:p])
                # Strict comparison: ties, -inf initialization and NaNs do not
                # silently bypass selection. All-pose statistics still run.
                torch.lt(workspace.gate_max[:p],self.cutoff,out=workspace.gate_active[:p])
                workspace.gate_active[:p].logical_not_()
            with topk_stage(timer,detailed,"gate_compact"):
                # CUDA nonzero has a dynamic result size and can synchronize.
                # Expose this cost explicitly rather than hiding it in topk.
                active = torch.nonzero(workspace.gate_active[:p],as_tuple=False).flatten()
                n = active.numel()
            self.skip_counts["bounds_checked"] += p
            self.skip_counts["skipped"] += p-n
            if n == 0:
                self.skip_counts["all_skipped_batches"] += 1
                return
            if n == p:
                active = None
            else:
                self.skip_counts["partial_batches"] += 1
        if active is None:
            self.skip_counts["selected"] += p
            merged = workspace.merged[:p,:m+b]
            if incoming_scores is not None:
                with topk_stage(timer,detailed,"copy_incoming"):
                    merged[:,m:].copy_(source)
            self._select_rows(self.values,self.ids,merged,workspace,pose_ids,timer,detailed)
            with topk_stage(timer,detailed,"cutoff_update"):
                torch.amin(self.values,dim=1,out=self.cutoff)
            return
        n = active.numel()
        self.skip_counts["selected"] += n
        merged = workspace.compact_merge[:n,:m+b]
        values,ids = workspace.compact_values[:n],workspace.compact_ids[:n]
        with topk_stage(timer,detailed,"gather_active"):
            if incoming_scores is None:
                torch.index_select(source,0,active,out=merged[:,m:])
            else:
                # Original dense merge buffer is idle in this path. Reuse its
                # flat storage for a packed B x active-P gather, never convert
                # the complete transposed source into a contiguous tensor.
                selected = workspace.merged.view(-1)[:b*n].view(b,n)
                torch.index_select(incoming_scores,1,active,out=selected)
                merged[:,m:].copy_(selected.T)
            torch.index_select(self.values,0,active,out=values)
            torch.index_select(self.ids,0,active,out=ids)
        self._select_rows(values,ids,merged,workspace,pose_ids,timer,detailed)
        with topk_stage(timer,detailed,"cutoff_update"):
            torch.amin(values,dim=1,out=workspace.gate_min[:n])
            self.cutoff.index_copy_(0,active,workspace.gate_min[:n])
        with topk_stage(timer,detailed,"scatter_active"):
            self.values.index_copy_(0,active,values)
            self.ids.index_copy_(0,active,ids)

    def _select_rows(self,values,ids,merged,workspace,pose_ids,timer,detailed):
        p,m = values.shape
        with topk_stage(timer,detailed,"copy_history"):
            merged[:,:m].copy_(values)
        index = workspace.index[:p]
        with topk_stage(timer,detailed,"select_values"):
            torch.topk(merged,m,dim=1,sorted=False,out=(values,index))
        # Save previous IDs before overwriting state. All scratch arrays persist.
        with topk_stage(timer,detailed,"id_prepare_indices"):
            torch.lt(index,m,out=workspace.is_old[:p])
            torch.clamp(index,max=m-1,out=workspace.old_index[:p])
        with topk_stage(timer,detailed,"id_gather_previous"):
            torch.gather(ids,1,workspace.old_index[:p],out=workspace.old_ids[:p])
        with topk_stage(timer,detailed,"id_gather_incoming"):
            index.sub_(m).clamp_min_(0)
            torch.take(pose_ids,index,out=ids)
        with topk_stage(timer,detailed,"id_merge"):
            torch.where(workspace.is_old[:p],workspace.old_ids[:p],ids,out=ids)

    def scores(self,mean,std):
        denominator = torch.where(std>0,std,1).reshape(-1,1)
        scores = ((self.values.to(mean.dtype)-mean.reshape(-1,1))/denominator).float()
        scores.masked_fill_(~(std>0).reshape(-1,1),0)
        scores.masked_fill_(self.ids<0,-torch.inf)
        return scores


def sparse_group_peaks(scores,ids,shape,core_size,threshold):
    """One peak per pose and flattened 1024-pixel CORE group among retained entries.

    This is explicitly a truncated candidate rule, not a reconstruction of the
    original all-orientation candidates. Score ties use the smallest position.
    """
    h,w = shape
    positions,ranks = torch.where(torch.isfinite(scores)&(scores>=threshold)&(ids>=0))
    if not len(positions):
        return torch.empty((0,4),device=scores.device)
    yy,xx = positions//w,positions%w
    flat = yy*core_size+xx
    ngroups = (core_size*core_size+1023)//1024
    poses = ids[positions,ranks].long()
    keys = poses*ngroups+flat//1024
    unique,inverse = torch.unique(keys,return_inverse=True)
    values = scores[positions,ranks]
    maxima = values.new_full((len(unique),),-torch.inf)
    maxima.scatter_reduce_(0,inverse,values,reduce="amax",include_self=True)
    winner = torch.full((len(unique),),torch.iinfo(torch.int64).max,device=scores.device,dtype=torch.int64)
    location = torch.where(values==maxima[inverse],flat,torch.iinfo(torch.int64).max)
    winner.scatter_reduce_(0,inverse,location,reduce="amin",include_self=True)
    # Float64 transport keeps integer coordinates and pose IDs exact. It is
    # used only for reduced rows, never for the correlation batch.
    return torch.stack(tuple(t.double() for t in (winner%core_size,winner//core_size,unique//ngroups,maxima)),dim=1)


class CandidateTable:
    """Compact NumPy storage; instantiate Pick objects only while streaming rows."""
    def __init__(self,rows,views,psi):
        self.rows = np.asarray(rows,dtype=np.float64).reshape(-1,5) # x,y,pose,score,tile
        self.views,self.psi = views,psi

    def __len__(self):
        return len(self.rows)

    def __getitem__(self,index):
        from .engine import Pick
        x,y,pose,score,tile = self.rows[index]
        pi,vi = divmod(int(pose),len(self.views))
        phi,theta = self.views[vi]
        return Pick(int(x),int(y),phi,theta,self.psi[pi],float(score),vi,int(tile))

    def __iter__(self):
        for i in range(len(self)):
            yield self[i]

    def take(self,indices):
        return CandidateTable(self.rows[indices],self.views,self.psi)
