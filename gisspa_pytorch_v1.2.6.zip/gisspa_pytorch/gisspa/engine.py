from __future__ import annotations

import json
import math
import shlex
import tempfile
import time
from dataclasses import asdict, dataclass
from pathlib import Path
from contextlib import nullcontext

import numpy as np
import torch
import mrcfile

from . import __version__
from .filters import (prepare_templates, prepare_image, mask_and_normalize,
                      tile_fourier, correlate)
from .geometry import EulerSearch, cisTEM_rotation_matrix
from .projector import FourierProjector, rotate_fourier
from .runtime import SpectrumBank, TemplateRotator, CandidateBuffer, tile_group_count, use_device_bank
from .mrcio import read_mrc, write_mrc
from .star import (read_micrographs, write_picks, write_lst, write_star, pick_row,
                   optics_row, OPTICS_COLUMNS, PICK_COLUMNS)


@dataclass
class Pick:
    x: int
    y: int
    phi: float
    theta: float
    psi: float
    score: float
    view_index: int = 0
    tile_index: int = 0


def choose_device(name):
    if name == "auto":
        name = "cuda" if torch.cuda.is_available() else "cpu"
    device = torch.device(name)
    if device.type not in ("cpu", "cuda"):
        raise ValueError("only CPU and CUDA devices are supported")
    if device.type == "cuda" and not torch.cuda.is_available():
        raise ValueError("CUDA requested but unavailable; install CUDA-enabled PyTorch or use device=cpu")
    if device.type == "cuda":
        torch.empty(1, device=device)
    return device


def axis_offsets(size, window, overlap):
    offsets = [0]
    while offsets[-1] + window < size:
        offsets.append(min(offsets[-1] + window - overlap, size - window))
    return offsets


def read_views(cfg):
    if cfg.orientations_file:
        views = []
        for line in Path(cfg.orientations_file).read_text(encoding="utf-8-sig").splitlines():
            values = shlex.split(line, comments=True)
            if not values:
                continue
            if len(values) != 2:
                raise ValueError("orientations_file must contain two cisTEM columns: phi theta; no implicit legacy conversion")
            phi, theta = map(float, values)
            if not all(math.isfinite(x) for x in (phi, theta)) or not 0 <= theta <= 180:
                raise ValueError("invalid phi/theta orientation")
            views.append((phi, theta))
    else:
        views = EulerSearch(cfg.symmetry, cfg.angular_step, cfg.psi_step,
                            preserve_psi_360_duplicate=False).out_of_plane_positions()
    if not views:
        raise ValueError("empty orientation list")
    # GisSPA uses a float32 accumulation loop with psi < 360, not <= 360.
    psi, value, step = [], np.float32(0), np.float32(cfg.psi_step)
    while value < np.float32(360):
        psi.append(float(value))
        new = np.float32(value + step)
        if new <= value:
            raise ValueError("psi_step is too small for float32 accumulation")
        value = new
    if len(views) * len(psi) < 2:
        raise ValueError("norm_type=1 requires at least two orientations")
    return views, psi


class Moments:
    def __init__(self, shape, device, precision="float64"):
        self.precision = precision
        self.sum = torch.zeros(shape, device=device, dtype=torch.float32 if precision == "mixed" else torch.float64)
        self.sum2 = torch.zeros_like(self.sum)
        self.count = 0

    def add(self, batch):
        values = batch.float() if self.precision == "mixed" else batch.double()
        self.sum += values.sum(0)
        self.sum2 += values.square().sum(0)
        self.count += len(batch)

    def add_pixels(self,incoming,workspace):
        """Consume P x B raw scores AFTER Top-M, reusing their storage for squares.

        This includes every pose, not just selected scores. State reductions and
        double diagnostics use workspace shared across sequential tiles.
        """
        p,b = incoming.shape
        if self.sum.numel() != p:
            raise ValueError("moment shape does not match incoming pixels")
        values = incoming
        if self.precision == "float64":
            values = workspace.double_values[:p,:b]
            values.copy_(incoming)
        reduced = workspace.reduction[:p]
        torch.sum(values,dim=1,out=reduced)
        self.sum.view(-1).add_(reduced)
        values.square_()
        torch.sum(values,dim=1,out=reduced)
        self.sum2.view(-1).add_(reduced)
        self.count += b

    def add_contiguous(self,batch,workspace,scratch=False):
        """Reduce ALL poses on tightly packed B x P storage after Top-M copies.

        Default consumes the crop buffer in place; scratch mode preserves it
        and squares into a second reusable contiguous buffer for comparison.
        """
        b,p = batch.shape
        if not batch.is_contiguous() or self.sum.numel() != p:
            raise ValueError("statistics require contiguous B x P scores matching the moment shape")
        values = batch
        if self.precision == "float64":
            values = workspace.double_values.view(-1)[:b*p].view(b,p)
            values.copy_(batch)
        reduced = workspace.reduction[:p]
        torch.sum(values,dim=0,out=reduced)
        self.sum.view(-1).add_(reduced)
        if scratch:
            squares = workspace.square_values[:b*p].view(b,p)
            torch.square(values,out=squares)
        else:
            squares = values.square_()
        torch.sum(squares,dim=0,out=reduced)
        self.sum2.view(-1).add_(reduced)
        self.count += b

    def finish(self):
        if not self.count:
            raise ValueError("empty correlation statistics")
        # Only completed 2-D maps are promoted, never a full batch in mixed mode.
        mean = self.sum.double() / self.count
        var = (self.sum2.double() / self.count - mean.square()).clamp_min(0)
        std = var.sqrt()
        if self.precision == "mixed":
            return mean.float(), std.float()
        return mean, std


def group_peaks(scores):
    """Reproduce 1024-element CUDA reductions, including tie traversal order."""
    flat = scores.reshape(scores.shape[0], -1)
    if flat.shape[1] % 1024:
        raise ValueError("correlation area must be divisible by 1024")
    values = flat.reshape(flat.shape[0], -1, 1024)
    indices = torch.arange(1024, device=scores.device).reshape(1, 1, 1024).expand_as(values)
    stride = 512
    while stride:
        take = values[..., stride:2 * stride] > values[..., :stride]
        indices = torch.where(take, indices[..., stride:2 * stride], indices[..., :stride])
        values = torch.where(take, values[..., stride:2 * stride], values[..., :stride])
        stride //= 2
    offsets = torch.arange(values.shape[1], device=scores.device) * 1024
    return values[..., 0], indices[..., 0] + offsets


def deduplicate(picks, distance, angle, allow_180=True):
    """Original pairwise order/score suppression, using cisTEM matrices.

    Optional 180-degree folding retains the old script's near-180 comparison.
    No quaternion sign branches or JSPR Euler formulas are used.
    """
    if not picks:
        return []
    orientations = torch.tensor([(p.phi, p.theta, p.psi) for p in picks], dtype=torch.float64)
    matrices = cisTEM_rotation_matrix(*orientations.unbind(1), dtype=torch.float64)
    positions = torch.tensor([(p.x, p.y) for p in picks], dtype=torch.float64)
    deleted = np.zeros(len(picks), dtype=bool)
    for i, pick in enumerate(picks):
        if deleted[i]:
            continue
        spatial = (positions[i + 1:] - positions[i]).square().sum(1) < distance ** 2
        candidates = spatial.nonzero().flatten() + i + 1
        if not len(candidates):
            continue
        traces = (matrices[candidates] * matrices[i]).sum((1, 2))
        delta = torch.acos(((traces - 1) / 2).clamp(-1, 1)) * (180 / math.pi)
        close = delta < angle
        if allow_180:
            close |= (180 - delta) < angle
        for j in candidates[close].tolist():
            if deleted[j]:
                continue
            if pick.score > picks[j].score:
                deleted[j] = True
            else:
                deleted[i] = True
    return [p for i, p in enumerate(picks) if not deleted[i]]


def build_template_bank(cfg, record, views, device, directory, log, timer=None):
    try:
        return _build_template_bank_once(cfg,record,views,device,directory,log,timer)
    except torch.cuda.OutOfMemoryError:
        if cfg.template_cache != "auto" or device.type != "cuda":
            raise
    # Outside the except suite: release its traceback and GPU batch references
    # before retrying without a resident bank. Never silently change batch size.
    torch.cuda.empty_cache()
    log("Automatic resident cache ran out of memory; rebuilding with an mmap cache")
    return _build_template_bank_once(cfg,record,views,device,directory,log,timer,force_mmap=True)


def _build_template_bank_once(cfg,record,views,device,directory,log,timer,force_mmap=False):
    bank_path = Path(directory) / "prepared_spectra.npy"
    n, batch_size = cfg.window_size, cfg.orientation_batch_size
    bank = None
    try:
        if cfg.template_mrc:
            data, template_pixel = read_mrc(cfg.template_mrc, cfg.template_pixel_size, volume=True)
            size = cfg.projection_size or max(4, 2 * math.ceil(data.shape[0] * template_pixel / record.pixel_size / 2))
            if size > n:
                raise ValueError(f"projection_size={size} exceeds window_size={n}; increase window_size")
            projector = FourierProjector(torch.from_numpy(data).to(device))
            stack = None
        else:
            stack, template_pixel = read_mrc(cfg.template_stack, cfg.template_pixel_size, stack=True)
            if len(stack) != len(views):
                raise ValueError(f"stack has {len(stack)} images but orientations_file has {len(views)} rows")
            if not math.isclose(template_pixel, record.pixel_size, rel_tol=1e-4):
                raise ValueError("template stack and micrograph pixel sizes must agree; use a 3-D volume for resampling")
        shape = (len(views),n,n//2+1)
        resident = not force_mmap and use_device_bank(math.prod(shape)*8,cfg,device)
        if resident:
            bank = torch.empty(shape,device=device,dtype=torch.complex64)
            log("Building base spectra directly in device memory; no cache file or host round trip")
        else:
            bank = np.lib.format.open_memmap(bank_path,mode="w+",dtype=np.complex64,shape=shape)
        for start in range(0, len(views), batch_size):
            stop = min(start + batch_size, len(views))
            if stack is None:
                angles = torch.tensor(views[start:stop], device=device, dtype=torch.float32)
                matrices = cisTEM_rotation_matrix(angles[:, 0], angles[:, 1], 0, device=device)
                with timer.section("template.base_projection") if timer else nullcontext():
                    raw = projector.project(matrices, size, template_pixel, record.pixel_size)
            else:
                raw = torch.from_numpy(stack[start:stop].copy()).to(device)
            with timer.section("template.base_filter_normalize") if timer else nullcontext():
                processed = prepare_templates(raw, record, cfg)
            if not torch.isfinite(processed).all():
                raise ValueError("template preprocessing produced non-finite data")
            with timer.section("template.base_fft_and_write") if timer else nullcontext():
                centered_f = torch.fft.rfft2(torch.fft.ifftshift(processed, dim=(-2,-1)), norm="forward")
                if resident:
                    bank[start:stop].copy_(centered_f)
                else:
                    bank[start:stop] = centered_f.cpu().numpy()
            if start == 0 or stop == len(views) or stop % (batch_size * 100) == 0:
                log(f"Prepared base views {stop}/{len(views)}")
        if resident:
            return bank
        bank.flush()
    finally:
        if isinstance(bank,np.memmap):
            bank._mmap.close()
    return bank_path


def iter_templates(bank, views, psi_values, cfg, device):
    for psi in psi_values:
        for start in range(0, len(views), cfg.orientation_batch_size):
            stop = min(start + cfg.orientation_batch_size, len(views))
            base = torch.from_numpy(np.array(bank[start:stop], copy=True)).to(device)
            rotated = rotate_fourier(base, psi)
            real = mask_and_normalize(rotated, cfg)
            yield start, psi, torch.fft.rfft2(real, norm="forward")


def match_image_legacy(cfg, record, views, psi_values, device, job_dir, log):
    original, _ = read_mrc(record.path, record.pixel_size, image_slice=record.image_slice)
    h, w = original.shape
    image = prepare_image(torch.from_numpy(original).to(device), record, cfg)
    xs = axis_offsets(w, cfg.window_size, cfg.overlap)
    ys = axis_offsets(h, cfg.window_size, cfg.overlap)
    offsets = [(y,x) for y in ys for x in xs]
    n, batch_size = cfg.window_size, cfg.orientation_batch_size
    count = len(views) * len(psi_values)
    log(f"{w}x{h}; {len(offsets)} tiles; {count} orientations; full-image search")
    if cfg.overlap < cfg.diameter and len(offsets) > 1:
        log("Note: overlap is smaller than diameter; particles crossing tile boundaries may be truncated")
    from .peaks import MatchPicks,peaks_from_maps,automatic_threshold_info,split_threshold_candidates
    auto_info = automatic_threshold_info(int(original.size),count)
    picks = MatchPicks()
    maps = {name: np.zeros((h,w),dtype=np.float32) for name in ("score","rot","tilt","psi")} if cfg.write_maps or cfg.cistem_peak_picking else {}
    if maps:
        maps["score"].fill(-np.inf)
    views_np = np.asarray(views,dtype=np.float32)
    candidates = CandidateBuffer(cfg,views,offsets,(h,w),picks,Pick,
                                 threshold=min(cfg.threshold,auto_info['threshold']))
    rotator = TemplateRotator(n,cfg,device)
    start_time, last_update = time.monotonic(), time.monotonic()
    performance = {"tile_count":len(offsets),"views":len(views),"psi_positions":len(psi_values),
                   "statistics_precision":cfg.statistics_precision,"full_image_search":True}
    with tempfile.TemporaryDirectory(prefix=".gisspa-cache-",dir=job_dir) as cache:
        bank_path = build_template_bank(cfg,record,views,device,cache,log)
        bank = SpectrumBank(bank_path,cfg,device,log)
        del bank_path
        try:
            group_size = tile_group_count(cfg,device,len(offsets))
            performance.update(tile_group_size=group_size,template_cache=bank.mode)
            log(f"Reusing templates across up to {group_size} tiles; statistics={cfg.statistics_precision}")
            for group_start in range(0,len(offsets),group_size):
                group_end = min(group_start+group_size,len(offsets))
                states = []
                for tile_id in range(group_start,group_end):
                    y,x = offsets[tile_id]
                    use_h,use_w = min(n,h-y),min(n,w-x)
                    tile = image.new_zeros((n,n))
                    tile[:use_h,:use_w] = image[y:y+use_h,x:x+use_w]
                    state = {"id":tile_id,"y":y,"x":x,"h":use_h,"w":use_w,
                             "image_f":tile_fourier(tile,cfg),
                             "moments":Moments((n,n),device,cfg.statistics_precision)}
                    states.append(state)
                del tile
                for pass_index in (0,1):
                    log(f"Tiles {group_start+1}-{group_end}/{len(offsets)}; pass {pass_index+1}/2")
                    for psi in psi_values:
                        rotator.set_angle(psi)
                        for view_start in range(0,len(views),batch_size):
                            view_end = min(view_start+batch_size,len(views))
                            base_f = bank.get(view_start,view_end)
                            temp_f = rotator.prepare(base_f)
                            for state in states:
                                cc = correlate(state["image_f"],temp_f,n)
                                if pass_index == 0:
                                    state["moments"].add(cc)
                                else:
                                    if cfg.statistics_precision == "float64":
                                        scores = ((cc.double()-state["mean"])/state["denominator"]).float()
                                    else:
                                        # Reuse the correlation buffer for float32 scoring.
                                        scores = cc.sub_(state["mean"]).div_(state["denominator"])
                                    scores.masked_fill_(~state["nonzero_std"],0)
                                    if maps:
                                        val,arg = scores.max(0)
                                        improved = val > state["best"]
                                        state["view"] = torch.where(improved,(arg+view_start).to(torch.int32),state["view"])
                                        state["psi"] = torch.where(improved,psi,state["psi"])
                                        torch.maximum(state["best"],val,out=state["best"])
                                    # Only array padding outside the real image is invalid.
                                    # Mask before reduction so padding cannot hide a real peak.
                                    if state["h"] < n:
                                        scores[...,state["h"]:,:] = -torch.inf
                                    if state["w"] < n:
                                        scores[...,:,state["w"]:] = -torch.inf
                                    peaks,positions = group_peaks(scores)
                                    candidates.add(peaks,positions,state["id"],view_start,psi)
                            if time.monotonic()-last_update > 20:
                                log(f"Pass {pass_index+1}: psi={psi:g}; views {view_end}/{len(views)}; tiles {group_start+1}-{group_end}")
                                last_update = time.monotonic()
                    if pass_index == 0:
                        for state in states:
                            mean,std = state.pop("moments").finish()
                            if not torch.isfinite(mean).all() or not torch.isfinite(std).all():
                                raise ValueError("non-finite correlation statistics; inspect input scale and templates")
                            state["mean"],state["nonzero_std"] = mean,std>0
                            state["denominator"] = torch.where(std>0,std,1)
                            if maps:
                                state["best"] = torch.full((n,n),-torch.inf,device=device)
                                state["view"] = torch.zeros((n,n),dtype=torch.int32,device=device)
                                state["psi"] = torch.zeros((n,n),device=device)
                candidates.flush()
                if maps:
                    for state in states:
                        use_h,use_w,y,x = state["h"],state["w"],state["y"],state["x"]
                        score_np = state["best"][:use_h,:use_w].cpu().numpy()
                        view_np = state["view"][:use_h,:use_w].cpu().numpy()
                        psi_np = state["psi"][:use_h,:use_w].cpu().numpy()
                        target = np.s_[y:y+use_h,x:x+use_w]
                        improved = score_np > maps["score"][target]
                        angles = views_np[view_np]
                        for name,array in (("score",score_np),("rot",angles[...,0]),("tilt",angles[...,1]),("psi",psi_np)):
                            patch = maps[name][target]
                            patch[improved] = array[improved]
                log(f"Tiles {group_start+1}-{group_end} complete; {len(picks)} raw candidates so far")
                del states, state, base_f, temp_f, cc
            performance.update(template_batch_loads=bank.loads,prepared_template_batches=rotator.prepared_batches,
                               rotation_plan_builds=rotator.plan_builds,candidate_transfer_flushes=candidates.flushes)
        finally:
            bank.close()
    # Preserve the original Psi -> tile -> view -> reduction-group order.
    picks.sort(key=lambda p:(p.psi,p.tile_index,p.view_index,
        ((p.y-offsets[p.tile_index][0])*n+p.x-offsets[p.tile_index][1])//1024))
    picks = split_threshold_candidates(picks,cfg.threshold,auto_info)
    performance['auto_threshold'] = dict(auto_info,raw_candidates=len(picks.auto_candidates))
    if cfg.write_maps:
        for name,array in maps.items():
            if not np.isfinite(array).all():
                raise ValueError(f"non-finite or uncovered full-image {name} map")
            write_mrc(job_dir/f"best_{name}.mrc",array,record.pixel_size)
        # Compatibility filename: every original image pixel is now searched.
        write_mrc(job_dir/"valid_search_mask.mrc",np.ones((h,w),dtype=np.float32),record.pixel_size)
    performance["elapsed_seconds"] = time.monotonic()-start_time
    (job_dir/"performance.json").write_text(json.dumps(performance,indent=2),encoding="utf-8")
    if cfg.cistem_peak_picking:
        picks.cistem_peaks,picks.cistem_peak_info = peaks_from_maps(maps,cfg,record)
    return picks, original


def match_image(cfg, record, views, psi_values, device, job_dir, log, timer=None):
    if cfg.search_mode == "legacy":
        return match_image_legacy(cfg,record,views,psi_values,device,job_dir,log)
    from .search import match_topk
    from .timing import Timer
    return match_topk(cfg,record,views,psi_values,device,job_dir,log,
                      timer or Timer(device,cfg.timing,cfg.timing_max_events))


def extract_particles(picks, original, box, path, pixel):
    kept, patches = [], []
    h, w = original.shape
    # Allocate on disk rather than building a second full particle stack in RAM.
    for p in picks:
        x0, y0 = p.x - box // 2, p.y - box // 2
        if 0 <= x0 and 0 <= y0 and x0 + box <= w and y0 + box <= h:
            kept.append(p)
            patches.append((y0, x0))
    names = []
    if kept:
        with mrcfile.new_mmap(path, shape=(len(kept), box, box), mrc_mode=2, overwrite=True) as handle:
            handle.voxel_size = pixel
            handle.set_image_stack()
            for i, (y, x) in enumerate(patches):
                handle.data[i] = original[y:y + box, x:x + box]
                names.append(f"{i + 1:06d}@{Path(path).resolve().as_posix()}")
            handle.update_header_stats()
    return kept, names


def deduplicate_candidates(raw,cfg,views,psi_values,device,timer,log):
    """Apply the same configured rule independently to either threshold branch."""
    from .picking import suppress
    from .topk import CandidateTable
    if cfg.deduplicate and cfg.dedup_mode != "legacy":
        if not isinstance(raw,CandidateTable):
            lookup = {float(p):i for i,p in enumerate(psi_values)}
            raw = CandidateTable([(p.x,p.y,lookup[p.psi]*len(views)+p.view_index,p.score,p.tile_index)
                                  for p in raw],views,psi_values)
        picks,info = suppress(raw,cfg,device,timer,log)
    else:
        picks = deduplicate(raw,cfg.dedup_distance or cfg.diameter/2,cfg.dedup_angle,cfg.dedup_allow_180) if cfg.deduplicate else raw
        info = {"mode":"legacy" if cfg.deduplicate else "disabled","input":len(raw),"kept":len(picks)}
    return raw,picks,info


@torch.inference_mode()
def process_micrograph(cfg,record,views,psi_values,device,index,total,log=print):
    """One full micrograph; called by both sequential and persistent-worker paths."""
    import os
    output = Path(cfg.output_dir)
    slug = "".join(c if c.isalnum() or c in "-_" else "_" for c in record.path.stem)
    job = output / f"{index + 1:05d}_{slug}"
    job.mkdir(parents=True, exist_ok=True)
    if cfg.overwrite:
        # Only remove this program's named previous outputs, never an arbitrary tree.
        for filename in ("candidates.star", "candidates.lst", "picks.star", "coordinates.star",
                         "candidates_auto_threshold.star", "picks_auto_threshold.star", "auto_threshold.json",
                         "particles.star", "particles.mrcs", "summary.json", "best_score.mrc",
                         "best_rot.mrc", "best_tilt.mrc", "best_psi.mrc", "valid_search_mask.mrc", "performance.json",
                         "top_m_cutoff.mrc", "timing.json", "timing.tsv", "deduplication.json", "cistem_peaks.star", "cistem_peaks.json", "inverse_fft_profile.json", "inverse_fft_profile.txt", "error.txt"):
            stale = job / filename
            if stale.is_file():
                stale.unlink()
    log(f"[{index + 1}/{total}] {record.path} on {device}")
    from .timing import Timer
    timer = Timer(device,cfg.timing,cfg.timing_max_events)
    if device.type == "cuda":
        torch.cuda.reset_peak_memory_stats(device)
    try:
        with timer.section("matching.total"):
            raw, original = match_image(cfg, record, views, psi_values, device, job, log,timer)
        extra_peaks = getattr(raw,"cistem_peaks",None)
        extra_info = getattr(raw,"cistem_peak_info",None)
        auto_raw = raw.auto_candidates
        auto_info = dict(raw.auto_threshold_info)
        if extra_peaks is not None:
            with timer.section("output.cistem_peaks_star",gpu=False):
                write_picks(job/"cistem_peaks.star",extra_peaks,record)
                (job/"cistem_peaks.json").write_text(json.dumps(extra_info,indent=2),encoding="utf-8")
            log(f"cisTEM-style peaks: {len(extra_peaks)}; radius={extra_info['radius_pixels']:.3f} px; "
                f"threshold={extra_info['threshold']:g}; limit={extra_info['maximum_peaks']}; "
                f"stopped_at_limit={extra_info['stopped_at_limit']}")
        with timer.section("dedup.total"):
            raw,picks,dedup_info = deduplicate_candidates(raw,cfg,views,psi_values,device,timer,log)
        (job/"deduplication.json").write_text(json.dumps(dedup_info,indent=2),encoding="utf-8")
        with timer.section("output.candidates_star_lst",gpu=False):
            write_picks(job / "candidates.star", raw, record)
            if cfg.write_lst:
                write_lst(job / "candidates.lst", raw, record)
        with timer.section("output.picks_star",gpu=False):
            write_picks(job / "picks.star", picks, record)
        with timer.section("dedup.auto_threshold_total"):
            auto_raw,auto_picks,auto_dedup_info = deduplicate_candidates(
                auto_raw,cfg,views,psi_values,device,timer,log)
        auto_info.update(manual_threshold=cfg.threshold,search_mode=cfg.search_mode,
                         raw_candidates=len(auto_raw),picks=len(auto_picks),
                         deduplication=auto_dedup_info,
                         score_source='GisSPA candidate z-score',
                         candidate_rule='unchanged; Top-M then per-pose group peaks' if cfg.search_mode=='topk'
                                        else 'unchanged; per-pose group peaks')
        with timer.section("output.auto_threshold_star",gpu=False):
            write_picks(job / "candidates_auto_threshold.star",auto_raw,record)
            write_picks(job / "picks_auto_threshold.star",auto_picks,record)
            (job / "auto_threshold.json").write_text(json.dumps(auto_info,indent=2),encoding="utf-8")
        log(f"Automatic threshold={auto_info['threshold']:.9g}: {len(auto_raw)} candidates, {len(auto_picks)} picks")
    except Exception:
        timer.write(job)
        raise
    # RELION Import coordinates accepts per-micrograph coordinate STAR files.
    with timer.section("output.coordinates_star",gpu=False):
        write_star(job / "coordinates.star", [("", ["_rlnCoordinateX", "_rlnCoordinateY", "_rlnAutopickFigureOfMerit"],
                    ({"_rlnCoordinateX": p.x, "_rlnCoordinateY": p.y, "_rlnAutopickFigureOfMerit": p.score} for p in picks))])
    info = {"micrograph": record.path.as_posix(), "image_slice": record.image_slice,
            "status":"complete", "index":index, "device":str(device), "worker_pid":os.getpid(),
            "pixel_size": record.pixel_size, "raw_candidates": len(raw), "picks": len(picks),
            "output_directory": str(job.resolve()), "input_optics": record.optics, "input_row": record.raw}
    info['auto_threshold'] = auto_info
    info['candidates_auto_threshold_star'] = str((job/'candidates_auto_threshold.star').resolve())
    info['picks_auto_threshold_star'] = str((job/'picks_auto_threshold.star').resolve())
    if extra_peaks is not None:
        info["cistem_peaks"] = extra_info
        info["cistem_peaks_star"] = str((job/"cistem_peaks.star").resolve())
    if cfg.extract_box_size:
        with timer.section("output.extract_and_particles_star",gpu=False):
            extracted, names = extract_particles(picks, original, cfg.extract_box_size, job / "particles.mrcs", record.pixel_size)
            write_picks(job / "particles.star", extracted, record, names, cfg.extract_box_size)
        info["extracted_particles"] = len(extracted)
        info["extraction_edge_rejections"] = len(picks) - len(extracted)
    timing_report = timer.write(job)
    info["timing_file"] = str(job/"timing.json")
    info["elapsed_job_seconds"] = timing_report["elapsed_wall_seconds"]
    info["cuda_peak_allocated_bytes"] = torch.cuda.max_memory_allocated(device) if device.type=="cuda" else None
    info["cuda_peak_reserved_bytes"] = torch.cuda.max_memory_reserved(device) if device.type=="cuda" else None
    (job / "summary.json").write_text(json.dumps(info, indent=2), encoding="utf-8")
    ranking = sorted(timer.rows.items(),key=lambda item:item[1]["cuda_seconds"] or item[1]["host_seconds"],reverse=True)
    for stage,row in ranking[:8]:
        elapsed = row["cuda_seconds"] if row["cuda_seconds"] is not None else row["host_seconds"]
        log(f"Timing {stage}: {elapsed:.3f}s ({row['calls']} calls)")
    log(f"Saved {len(picks)} picks ({len(raw)} before duplicate removal): {job}")
    return info


def run(cfg,log=print):
    from .batch import run_batch
    return run_batch(cfg,log)
