"""Persistent spawned workers, one whole micrograph per GPU at a time.

Scheduling follows cistem2dtm's spawn/long-lived worker model. The parent assigns
the next job to the worker that finishes first. IPC carries CPU metadata only.
"""
from dataclasses import replace
import json
import multiprocessing as mp
import os
from pathlib import Path
import queue
import time
import traceback
import numpy as np
import torch
import mrcfile
from . import __version__
from .star import read_micrographs,read_star,write_star,optics_row,OPTICS_COLUMNS,PICK_COLUMNS
from .timing import Timer


MERGED_FILES = ('all_picks.star','all_cistem_peaks.star','all_particles.star',
                'all_candidates_auto_threshold.star','all_picks_auto_threshold.star')


def parse_gpu_ids(text):
    if text.strip().lower() == 'all':
        count=torch.cuda.device_count()
        if not count:
            raise ValueError('--gpus all requested but no CUDA devices are visible')
        return list(range(count))
    parts=text.split(',')
    if not parts or any(not p.strip().isascii() or not p.strip().isdigit() for p in parts):
        raise ValueError('--gpus must be comma-separated nonnegative integers or all')
    ids=[int(p.strip()) for p in parts]
    if len(set(ids)) != len(ids):
        raise ValueError('--gpus must not repeat a GPU index')
    return ids


def resolve_worker_devices(cfg):
    if cfg.gpu_ids is None:
        return []
    visible=torch.cuda.device_count()
    invalid=[i for i in cfg.gpu_ids if i >= visible]
    if invalid:
        raise ValueError(f'GPU indices {invalid} are unavailable; visible CUDA device count={visible}. '
                         'Indices are relative to CUDA_VISIBLE_DEVICES.')
    return [f'cuda:{i}' for i in cfg.gpu_ids]


def job_directory(cfg,index,record):
    slug=''.join(c if c.isalnum() or c in '-_' else '_' for c in record.path.stem)
    return Path(cfg.output_dir)/f'{index+1:05d}_{slug}'


def atomic_json(path,value):
    path=Path(path)
    path.parent.mkdir(parents=True,exist_ok=True)
    temporary=path.with_name(path.name+'.tmp')
    temporary.write_text(json.dumps(value,indent=2),encoding='utf-8')
    temporary.replace(path)


def execute_job(cfg,record,views,psi,device,index,total,log):
    from .engine import process_micrograph
    job=job_directory(cfg,index,record)
    job.mkdir(parents=True,exist_ok=True)
    with (job/'run.log').open('w',encoding='utf-8',buffering=1) as stream:
        def emit(message):
            stream.write(str(message)+'\n')
            log(str(message))
        try:
            return process_micrograph(cfg,record,views,psi,device,index,total,emit)
        except BaseException as exc:
            detail=traceback.format_exc()
            (job/'error.txt').write_text(detail,encoding='utf-8')
            atomic_json(job/'summary.json',dict(status='failed',index=index,micrograph=record.path.as_posix(),
                output_directory=str(job.resolve()),device=str(device),worker_pid=os.getpid(),
                error=f'{type(exc).__name__}: {exc}'))
            stream.write(detail+'\n')
            raise


def _worker(worker_id,device_name,cfg,views,psi,total,tasks,results):
    """Initialize CUDA once, then process an arbitrary number of micrographs."""
    from .engine import choose_device
    index=None
    try:
        torch.set_num_threads(cfg.cpu_threads)
        torch.backends.cuda.matmul.allow_tf32=False
        if torch.device(device_name).type == 'cuda':
            torch.cuda.set_device(torch.device(device_name))
        device=choose_device(device_name)
        worker_cfg=replace(cfg,device=device_name,gpu_ids=None)
        results.put(dict(kind='ready',worker=worker_id,pid=os.getpid(),device=device_name))
        while True:
            task=tasks.get()
            if task is None:
                return
            index,record=task
            def log(message):
                results.put(dict(kind='log',worker=worker_id,index=index,message=message))
            info=execute_job(worker_cfg,record,views,psi,device,index,total,log)
            results.put(dict(kind='complete',worker=worker_id,index=index,info=info))
            index=None
    except BaseException as exc:
        results.put(dict(kind='failed',worker=worker_id,index=index,pid=os.getpid(),
                         error=f'{type(exc).__name__}: {exc}',traceback=traceback.format_exc()))


def _parallel(cfg,records,views,psi,devices,metadata,log,snapshot):
    context=mp.get_context('spawn')
    devices=devices[:len(records)]
    results=context.Queue()
    tasks=[context.Queue(maxsize=1) for _ in devices]
    processes=[]
    assigned={}
    completed={}
    ready=set()
    next_index=0
    metadata['workers']=[dict(worker=i,device=d,pid=None,status='starting',completed_jobs=0) for i,d in enumerate(devices)]
    def dispatch(worker):
        nonlocal next_index
        if next_index >= len(records):
            metadata['workers'][worker]['status']='idle'
            return
        index=next_index
        next_index+=1
        assigned[worker]=index
        metadata['jobs'][index].update(status='running',device=devices[worker],worker=worker)
        metadata['workers'][worker]['status']='running'
        tasks[worker].put((index,records[index]))
    try:
        for i,device in enumerate(devices):
            process=context.Process(target=_worker,args=(i,device,cfg,views,psi,len(records),tasks[i],results),daemon=False)
            process.start()
            processes.append(process)
            metadata['workers'][i]['pid']=process.pid
        deadline=time.monotonic()+cfg.worker_startup_timeout
        while len(completed) < len(records):
            try:
                event=results.get(timeout=0.5)
            except queue.Empty:
                event=None
            if event is not None:
                worker=event['worker']
                kind=event['kind']
                if kind == 'ready':
                    ready.add(worker)
                    metadata['workers'][worker].update(pid=event['pid'],status='idle')
                    log(f"Worker {worker} ready: {devices[worker]}, PID {event['pid']}")
                    if len(ready)==len(devices):
                        for wid in range(len(devices)):
                            dispatch(wid)
                        snapshot()
                elif kind == 'log':
                    log(f"[{devices[worker]} job {event['index']+1}] {event['message']}")
                elif kind == 'complete':
                    index=event['index']
                    if assigned.get(worker) != index or index in completed:
                        raise RuntimeError('worker returned an unexpected or duplicate job result')
                    info=event['info']
                    completed[index]=info
                    assigned.pop(worker)
                    metadata['jobs'][index].update(status='complete',worker_pid=info['worker_pid'])
                    metadata['workers'][worker]['completed_jobs']+=1
                    metadata['micrographs']=[completed[i] for i in sorted(completed)]
                    dispatch(worker)
                    snapshot()
                elif kind == 'failed':
                    metadata['workers'][worker]['status']='failed'
                    index=event['index']
                    if index is not None:
                        metadata['jobs'][index].update(status='failed',error=event['error'])
                    metadata['worker_error']=event
                    raise RuntimeError(f"Worker {worker} ({devices[worker]}) failed on job {index}: {event['error']}")
            # Check every worker, even if other GPUs are still producing results.
            for wid,process in enumerate(processes):
                if process.exitcode is not None:
                    raise RuntimeError(f'Worker {wid} ({devices[wid]}) exited unexpectedly, exit code {process.exitcode}')
            if len(ready)<len(devices) and time.monotonic()>deadline:
                raise RuntimeError(f'GPU worker initialization exceeded {cfg.worker_startup_timeout:g} seconds')
        for q in tasks:
            q.put(None)
        deadline=time.monotonic()+10
        for process in processes:
            process.join(timeout=max(0,deadline-time.monotonic()))
        if any(p.is_alive() or p.exitcode != 0 for p in processes):
            raise RuntimeError('a GPU worker did not shut down cleanly')
        for worker in metadata['workers']:
            worker['status']='stopped'
        return [completed[i] for i in range(len(records))]
    finally:
        for process in processes:
            if process.is_alive():
                process.terminate()
        deadline=time.monotonic()+5
        for process in processes:
            process.join(timeout=max(0,deadline-time.monotonic()))
            if process.is_alive():
                process.kill()
                process.join(timeout=1)
        for q in [*tasks,results]:
            q.cancel_join_thread()
            q.close()


def _merged_rows(records,infos,filename):
    """Read one job at a time; only parent writes root STAR files."""
    for index,info in enumerate(infos):
        loops=read_star(Path(info['output_directory'])/filename)
        table=next(loop for loop in loops if loop.block=='particles')
        for row in table.rows:
            row['_rlnOpticsGroup']=str(index+1)
            yield row


def merge_outputs(cfg,records,infos,timer):
    optics=[optics_row(record,str(i+1)) for i,record in enumerate(records)]
    kinds=[('all_picks.star','picks.star',OPTICS_COLUMNS,PICK_COLUMNS,optics)]
    kinds.extend((target,source,OPTICS_COLUMNS,PICK_COLUMNS,optics) for target,source in (
        ('all_candidates_auto_threshold.star','candidates_auto_threshold.star'),
        ('all_picks_auto_threshold.star','picks_auto_threshold.star')))
    if cfg.cistem_peak_picking:
        kinds.append(('all_cistem_peaks.star','cistem_peaks.star',OPTICS_COLUMNS,PICK_COLUMNS,optics))
    if cfg.extract_box_size:
        opt=[optics_row(record,str(i+1),cfg.extract_box_size) for i,record in enumerate(records)]
        kinds.append(('all_particles.star','particles.star',
            OPTICS_COLUMNS+['_rlnImagePixelSize','_rlnImageSize','_rlnImageDimensionality'],
            PICK_COLUMNS+['_rlnImageName','_rlnOriginXAngstrom','_rlnOriginYAngstrom'],opt))
    for target,source,opt_columns,columns,rows in kinds:
        with timer.section('output.'+target.replace('.','_'),gpu=False):
            path=Path(cfg.output_dir)/target
            temporary=path.with_name(path.name+'.tmp')
            write_star(temporary,[('optics',opt_columns,rows),('particles',columns,_merged_rows(records,infos,source))])
            temporary.replace(path)


def run_batch(cfg,log=print):
    from .engine import choose_device,read_views
    cfg.validate()
    devices=resolve_worker_devices(cfg)
    device=None if devices else choose_device(cfg.device)
    records=read_micrographs(cfg)
    views,psi=read_views(cfg)
    output=Path(cfg.output_dir)
    if output.exists() and any(output.iterdir()) and not cfg.overwrite:
        raise ValueError(f'output directory is not empty: {output}; choose another output_dir or set overwrite=true')
    output.mkdir(parents=True,exist_ok=True)
    if cfg.overwrite:
        for name in (*MERGED_FILES,'run_summary.json','timing.json','timing.tsv'):
            for path in (output/name,output/(name+'.tmp')):
                if path.is_file():
                    path.unlink()
    atomic_json(output/'config.resolved.json',cfg.to_dict())
    (output/'orientations.tsv').write_text('# cisTEM phi theta; psi sampled separately\n'+
        ''.join(f'{a:.9g}\t{b:.9g}\n' for a,b in views),encoding='utf-8')
    started=time.monotonic()
    timer=Timer('cpu',cfg.timing,cfg.timing_max_events)
    metadata=dict(version=__version__,device=','.join(devices) if devices else str(device),
        torch=torch.__version__,numpy=np.__version__,mrcfile=mrcfile.__version__,norm_type=1,
        geometry='cisTEM base central slices + Fourier in-plane rotation after GisSPA weighting',
        number_of_views=len(views),psi_values=psi,statistics_precision=cfg.statistics_precision,
        moments_dtype='float32' if cfg.statistics_precision=='mixed' else 'float64',
        variance_finalization_dtype='float64',full_image_search=True,search_mode=cfg.search_mode,
        top_m=cfg.top_m,dedup_mode=cfg.dedup_mode,status='running',micrographs=[],
        scheduling='persistent_micrograph_workers' if devices else 'sequential',
        requested_worker_devices=devices,active_worker_count=min(len(devices),len(records)) if devices else 1,
        cuda_visible_devices=os.environ.get('CUDA_VISIBLE_DEVICES'),
        jobs=[dict(index=i,micrograph=r.path.as_posix(),output_directory=str(job_directory(cfg,i,r).resolve()),status='pending') for i,r in enumerate(records)],
        workers=[])
    def snapshot():
        metadata['elapsed_seconds']=time.monotonic()-started
        atomic_json(output/'run_summary.json',metadata)
    snapshot()
    try:
        if devices:
            log(f"Persistent GPU workers: {devices[:len(records)]}; {len(records)} micrographs, one complete image per worker")
            with timer.section('batch.parallel_workers',gpu=False):
                metadata['micrographs']=_parallel(cfg,records,views,psi,devices,metadata,log,snapshot)
        else:
            torch.set_num_threads(cfg.cpu_threads)
            torch.backends.cuda.matmul.allow_tf32=False
            if device.type == 'cuda':
                torch.cuda.set_device(device)
            with timer.section('batch.sequential_jobs',gpu=False):
                for index,record in enumerate(records):
                    metadata['jobs'][index].update(status='running',device=str(device))
                    snapshot()
                    info=execute_job(cfg,record,views,psi,device,index,len(records),log)
                    metadata['micrographs'].append(info)
                    metadata['jobs'][index].update(status='complete',worker_pid=info['worker_pid'])
                    snapshot()
        merge_outputs(cfg,records,metadata['micrographs'],timer)
        metadata['status']='complete'
    except BaseException as exc:
        metadata['status']='interrupted' if isinstance(exc,KeyboardInterrupt) else 'failed'
        metadata['error']=f'{type(exc).__name__}: {exc}'
        for job in metadata['jobs']:
            if job['status']=='running':
                path=Path(job['output_directory'])/'summary.json'
                existing=json.loads(path.read_text(encoding='utf-8')) if path.is_file() else {}
                if existing.get('status')=='failed':
                    job.update(status='failed',error=existing.get('error'))
                else:
                    job['status']='aborted'
                    atomic_json(path,dict(status='aborted',index=job['index'],micrograph=job['micrograph'],
                        output_directory=job['output_directory'],error='batch aborted before job completion was acknowledged'))
        for worker in metadata['workers']:
            if worker['status'] not in ('stopped','failed'):
                worker['status']='terminated'
        # Never leave root merged STAR files looking like a successful full run.
        for name in MERGED_FILES:
            for path in (output/name,output/(name+'.tmp')):
                if path.is_file():
                    path.unlink()
        raise
    finally:
        snapshot()
        timer.write(output)
    return metadata
