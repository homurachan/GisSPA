"""Whole-micrograph padding and fixed windows; optional full-template halos."""
from dataclasses import dataclass, asdict
import math
import torch
from .filters import frequency_grid, frequency_weight, ctf_image


def good_size(value, mode="cistem-standard"):
    value = max(2,int(value))
    if mode == "exact":
        return value + value%2
    power = 1 << (value-1).bit_length()
    if mode == "power2":
        return power
    for limit in (2,3,5,7,9,13):
        primes = [p for p in (2,3,5,7,11,13) if p<=limit]
        candidate = value+value%2
        if limit == 2:
            candidate = power
        else:
            while True:
                remainder = candidate
                for p in primes:
                    while remainder%p == 0:
                        remainder //= p
                if remainder == 1:
                    break
                candidate += 2
        if candidate-value < value*.1:
            return candidate
    return candidate


@dataclass
class BoundaryPlan:
    original_shape: tuple
    padded_shape: tuple
    padding_top: int
    padding_left: int
    halo: int
    core_size: int
    fft_size: int
    offsets: list
    mode: str
    core_offset: int

    def to_dict(self):
        result = asdict(self)
        result["tile_count"] = len(self.offsets)
        result.pop("offsets")
        h,w = self.original_shape
        result["padding_bottom"] = self.padded_shape[0]-h-self.padding_top
        result["padding_right"] = self.padded_shape[1]-w-self.padding_left
        return result


def plan_boundary(shape,cfg):
    h,w = shape
    n = cfg.window_size
    core = n-cfg.overlap
    mode = cfg.boundary_mode
    if mode == "micrograph":
        halo = 0  # No extra input or FFT expansion around individual windows.
        fft = n
        offset = cfg.overlap//2
    elif mode == "template_halo":
        halo = n//2  # Restore full template support, never the hand-edited 32.
        fft = good_size(core+2*halo,cfg.fft_size_mode)
        offset = halo
    else:
        raise ValueError(f"unknown boundary_mode: {mode}")
    border = cfg.image_padding if cfg.image_padding is not None else n//2
    dims,origins = [],[]
    for size in (h,w):
        before = max(border,offset)
        last_core = (size-1)%core+1
        # Entire final fixed-size window must come from the global padded image.
        after = max(border,n-offset-last_core) if mode == "micrograph" else max(border,halo)
        needed = size+before+after
        padded = good_size(needed,cfg.fft_size_mode)
        dims.append(padded)
        origins.append(before+(padded-needed)//2)
    return BoundaryPlan((h,w),tuple(dims),origins[0],origins[1],halo,core,fft,
                        [(y,x) for y in range(0,h,core) for x in range(0,w,core)],mode,offset)


def _reference_whiten(spectrum, reference):
    """Estimate radial noise power only from real pixels; apply on padded grid."""
    shape = reference.shape
    f = torch.fft.rfft2(reference,norm="forward")
    _,_,_,bins,valid = frequency_grid(shape,reference.device)
    nbin = max(shape)//2
    counts = torch.bincount(bins[valid],minlength=nbin).float()
    sums = torch.zeros(nbin,device=reference.device)
    sums.scatter_add_(0,bins[valid],f[valid].abs().square())
    power = sums/counts.clamp_min(1)
    weights = torch.where(power>0,power.clamp_min(1e-30).rsqrt(),0)
    target = (spectrum.shape[-2],2*(spectrum.shape[-1]-1))
    xx,yy,_,_,_ = frequency_grid(target,reference.device)
    radius = torch.hypot(xx,yy)*max(shape)-1
    index = radius.floor().long().clamp(0,nbin-1)
    fraction = (radius-index).clamp(0,1)
    weight = weights[index]*(1-fraction)+weights[(index+1).clamp_max(nbin-1)]*fraction
    weight = torch.where((radius>=0)&(radius<nbin),weight,1)
    return spectrum*weight


def prepare_padded_image(image,record,cfg,plan,timer):
    with timer.section("image.outliers_and_noise_statistics"):
        variance,mean = torch.var_mean(image.double(),correction=0)
        if not bool(torch.isfinite(variance)) or not bool(variance>0):
            raise ValueError("input micrograph has no finite positive variance")
        sigma = variance.sqrt().to(image.dtype)
        cleaned = torch.where((image-mean.float()).abs()>6*sigma,mean.float(),image)
        if cfg.invert:
            cleaned = -cleaned
        cleaned = cleaned-cleaned.mean()
        sigma = cleaned.double().var(correction=0).sqrt().float()
    with timer.section("image.artificial_padding"):
        ph,pw = plan.padded_shape
        h,w = image.shape
        y,x = plan.padding_top,plan.padding_left
        if cfg.padding_mode == "noise":
            gen = torch.Generator(device=image.device).manual_seed(cfg.padding_seed)
            padded = torch.randn((ph,pw),generator=gen,device=image.device)*sigma
        elif cfg.padding_mode == "replicate":
            yy = (torch.arange(ph,device=image.device)-y).remainder(2*h)
            xx = (torch.arange(pw,device=image.device)-x).remainder(2*w)
            yy = torch.where(yy<h,yy,2*h-1-yy)
            xx = torch.where(xx<w,xx,2*w-1-xx)
            padded = cleaned[yy[:,None],xx[None,:]]
        else:
            padded = image.new_zeros((ph,pw))
        padded[y:y+h,x:x+w] = cleaned
    with timer.section("image.forward_fft"):
        spectrum = torch.fft.rfft2(padded,norm="forward")
    if cfg.phase_flip:
        with timer.section("image.phase_flip"):
            ctf = ctf_image(plan.padded_shape,record,image.device)
            spectrum *= torch.where(ctf>0,1,-1)
        with timer.section("image.reference_whitening"):
            spectrum = _reference_whiten(spectrum,cleaned)
        with timer.section("image.frequency_weight"):
            spectrum *= frequency_weight(plan.padded_shape,record,cfg,image.device)
    with timer.section("image.inverse_fft"):
        spectrum[0,0] = 0
        return torch.fft.irfft2(spectrum,s=plan.padded_shape,norm="forward")


def read_tile(image,plan,y,x):
    h,w = plan.original_shape
    uh,uw = min(plan.core_size,h-y),min(plan.core_size,w-x)
    sy,sx = y+plan.padding_top-plan.core_offset,x+plan.padding_left-plan.core_offset
    if plan.mode == "micrograph":
        # A view of the globally padded image: no tile padding or allocation.
        tile = image[sy:sy+plan.fft_size,sx:sx+plan.fft_size]
        if tile.shape != (plan.fft_size,plan.fft_size):
            raise RuntimeError("global padding does not contain the full tile")
        return tile,uh,uw
    tile = image.new_zeros((plan.fft_size,plan.fft_size))
    tile[:uh+2*plan.halo,:uw+2*plan.halo] = image[sy:sy+uh+2*plan.halo,sx:sx+uw+2*plan.halo]
    return tile,uh,uw
