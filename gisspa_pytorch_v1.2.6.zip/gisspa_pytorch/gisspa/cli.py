from __future__ import annotations

import argparse
import json
import math
import sys
from pathlib import Path

from . import __version__
from .config import load_config


def convert_lst(args):
    from .engine import Pick
    from .projector import legacy_lst_matrix, matrix_to_relion
    from .star import Micrograph, read_lst, write_star, optics_row, pick_row, OPTICS_COLUMNS, PICK_COLUMNS
    rows, detected = read_lst(args.input)
    convention = args.angles or detected
    if convention is None:
        raise ValueError("untagged LST: explicitly select --angles cistem, relion or gisspa-legacy")
    optics, result = [], []
    groups = {}
    for index, filename, fields in rows:
        path = Path(filename)
        if not path.is_absolute():
            path = Path(args.micrograph_root or Path(args.input).resolve().parent) / path
        path = path.resolve()
        if index != 0:
            raise ValueError("coordinate STAR conversion requires single-image micrographs (LST index 0); extract stack images first")
        if not all(k in fields for k in ("defocus", "euler", "center", "score")):
            raise ValueError("LST candidate missing defocus, euler, center or score")
        angle = tuple(map(float, fields["euler"].split(",")))
        if len(angle) != 3:
            raise ValueError("LST euler field must have three values")
        if convention == "gisspa-legacy":
            angle = tuple(matrix_to_relion(legacy_lst_matrix(*angle)).tolist())
        x, y = map(float, fields["center"].split(","))
        # Coordinates are rescaled only when the caller explicitly requests it.
        pick = Pick(x * args.coordinate_scale, y * args.coordinate_scale, *angle, float(fields["score"]))
        df, diff = float(fields["defocus"]), float(fields.get("dfdiff", 0))
        record = Micrograph(str(path), path, args.pixel_size, args.voltage, args.cs, args.amplitude_contrast,
                            (df - diff) * 10000, (df + diff) * 10000, float(fields.get("dfang", 0)))
        if path not in groups:
            group = str(len(groups) + 1)
            groups[path] = group
            optics.append(optics_row(record, group))
        result.append(pick_row(pick, record, groups[path]))
    output = Path(args.output)
    if output.exists() and not args.overwrite:
        raise ValueError(f"output exists: {output}; use --overwrite")
    write_star(output, [("optics", OPTICS_COLUMNS, optics), ("particles", PICK_COLUMNS, result)])
    print(f"Converted {len(result)} candidate rows: {output}")


def main(argv=None):
    parser = argparse.ArgumentParser(description="GisSPA norm_type=1, PyTorch / NumPy / mrcfile only")
    parser.add_argument("--version", action="version", version=__version__)
    parser.add_argument("--debug", action="store_true", help="print a traceback on failure")
    commands = parser.add_subparsers(dest="command", required=True)
    for name in ("run", "check"):
        sub = commands.add_parser(name, help="run matching" if name == "run" else "validate inputs and print work size")
        sub.add_argument("config")
        devices = sub.add_mutually_exclusive_group()
        devices.add_argument("--device",help="single-device execution; overrides config gpu_ids")
        devices.add_argument("--gpus",help="persistent GPU workers, e.g. 0,1,2,3 or all; overrides config device")
        sub.add_argument("--worker-startup-timeout",type=float,help="seconds allowed for spawned workers to initialize, default 180")
        sub.add_argument("--output-dir")
        sub.add_argument("--score-processing",choices=("contiguous","contiguous_scratch","direct"),
                         help="override crop/statistics layout for server comparison")
        sub.add_argument("--cache-template-conjugate",action=argparse.BooleanOptionalAction,default=None,
                         help="materialize each conjugate template batch once for tile reuse")
        sub.add_argument("--topk-skip-unchanged",action=argparse.BooleanOptionalAction,default=None,
                         help="experimental exact-value Top-M gate; statistics still use all poses")
        sub.add_argument("--topk-detailed-timing",action=argparse.BooleanOptionalAction,default=None,
                         help="record nested copy, selection, ID and gate stages")
        sub.add_argument("--inverse-fft-detailed-timing",action=argparse.BooleanOptionalAction,default=None)
        sub.add_argument("--fft-profile-calls",type=int,help="profile the first N correlation inverse FFT calls; 0 disables tracing")
        sub.add_argument("--cistem-peak-picking",action=argparse.BooleanOptionalAction,default=None)
        sub.add_argument("--cistem-peak-threshold",type=float,help="override only cistem_peaks.star cutoff; default is per-micrograph Gaussian threshold; *_auto_threshold.star always uses the automatic cutoff")
        sub.add_argument("--cistem-peak-radius-angstrom",type=float,help="inclusive spatial suppression radius in Angstrom; default 10")
        sub.add_argument("--cistem-maximum-peaks",type=int,help="per-micrograph limit; default 1000, 0 emits empty STAR")
        sub.add_argument("--overwrite", action="store_true")
    demo = commands.add_parser("demo", help="generate a small synthetic volume, image, STAR and configuration")
    demo.add_argument("--output", default="demo")
    demo.add_argument("--run", action="store_true", help="also execute matching")
    convert = commands.add_parser("convert-lst", help="convert candidate LST to RELION coordinate/pose STAR")
    convert.add_argument("input")
    convert.add_argument("output")
    convert.add_argument("--angles", choices=("cistem", "relion", "gisspa-legacy"))
    convert.add_argument("--pixel-size", type=float, required=True, help="target micrograph Angstrom/pixel")
    convert.add_argument("--coordinate-scale", type=float, default=1)
    convert.add_argument("--voltage", type=float, default=300)
    convert.add_argument("--cs", type=float, default=2.7)
    convert.add_argument("--amplitude-contrast", type=float, default=0.07)
    convert.add_argument("--micrograph-root")
    convert.add_argument("--overwrite", action="store_true")
    args = parser.parse_args(argv)
    try:
        if args.command == "convert-lst":
            numeric = (args.pixel_size, args.coordinate_scale, args.voltage, args.cs, args.amplitude_contrast)
            if not all(math.isfinite(v) for v in numeric):
                raise ValueError("numeric conversion arguments must be finite")
            if args.pixel_size <= 0 or args.coordinate_scale <= 0:
                raise ValueError("pixel-size and coordinate-scale must be positive")
            if args.voltage <= 0 or args.cs < 0 or not 0 <= args.amplitude_contrast < 1:
                raise ValueError("invalid microscope parameters")
            convert_lst(args)
            return 0
        if args.command == "demo":
            from .demo import make_demo
            path = make_demo(Path(args.output))
            print(f"Demo created. Run: python run_gisspa.py run \"{path}\"")
            if not args.run:
                return 0
            cfg = load_config(path)
        else:
            cfg = load_config(args.config)
            if args.device:
                cfg.device = args.device
                cfg.gpu_ids = None
            if args.gpus is not None:
                from .batch import parse_gpu_ids
                cfg.gpu_ids = parse_gpu_ids(args.gpus)
                cfg.device = "auto"
            if args.worker_startup_timeout is not None:
                cfg.worker_startup_timeout = args.worker_startup_timeout
            if args.score_processing:
                cfg.score_processing = args.score_processing
            for key in ("cache_template_conjugate","topk_skip_unchanged","topk_detailed_timing","inverse_fft_detailed_timing","fft_profile_calls","cistem_peak_picking","cistem_peak_threshold","cistem_peak_radius_angstrom","cistem_maximum_peaks"):
                if getattr(args,key) is not None:
                    setattr(cfg,key,getattr(args,key))
            if args.output_dir:
                cfg.output_dir = str(Path(args.output_dir).resolve())
            if args.overwrite:
                cfg.overwrite = True
        cfg.validate()
        from .engine import run, choose_device, read_views, axis_offsets
        if args.command == "check":
            from .star import read_micrographs
            from .mrcio import read_mrc
            from .batch import resolve_worker_devices
            worker_devices = resolve_worker_devices(cfg)
            device = worker_devices[0] if worker_devices else choose_device(cfg.device)
            records = read_micrographs(cfg)
            views, psi = read_views(cfg)
            template, tpix = read_mrc(cfg.template_mrc or cfg.template_stack, cfg.template_pixel_size,
                                      volume=bool(cfg.template_mrc), stack=bool(cfg.template_stack))
            if cfg.template_stack and len(template) != len(views):
                raise ValueError("template stack/orientation count mismatch")
            report = {"device": str(device), "gpu_ids":cfg.gpu_ids,
                      "worker_devices":worker_devices,"scheduling":"persistent_micrograph_workers" if worker_devices else "sequential",
                      "active_workers":min(len(worker_devices),len(records)) if worker_devices else 1, "micrographs": len(records), "views": len(views),
                      "psi_positions": len(psi), "total_orientations": len(views) * len(psi),
                      "template_shape": template.shape, "template_pixel_size": tpix,
                      "temporary_template_cache_gib_per_micrograph": len(views) * cfg.window_size * (cfg.window_size // 2 + 1) * 8 / 1024 ** 3,
                      "statistics_precision": cfg.statistics_precision, "template_cache": cfg.template_cache,
                      "tile_group_size_requested": cfg.tile_group_size, "full_image_search": True,
                      "jobs": []}
            for rec in records:
                data, _ = read_mrc(rec.path, rec.pixel_size, image_slice=rec.image_slice)
                h, w = data.shape
                if cfg.template_mrc:
                    projection_size = cfg.projection_size or max(4, 2 * math.ceil(template.shape[0] * tpix / rec.pixel_size / 2))
                    if projection_size > cfg.window_size:
                        raise ValueError(f"projection_size={projection_size} exceeds window_size={cfg.window_size}")
                else:
                    if max(template.shape[-2:]) > cfg.window_size:
                        raise ValueError("template stack images exceed window_size")
                    if not math.isclose(tpix, rec.pixel_size, rel_tol=1e-4):
                        raise ValueError("template stack and micrograph pixel sizes must agree")
                if cfg.search_mode == "topk":
                    from .boundary import plan_boundary
                    plan = plan_boundary((h,w),cfg)
                    tiles = len(plan.offsets)
                    job = {"boundary":plan.to_dict(),"top_m":min(cfg.top_m,len(views)*len(psi)),
                           "top_m_cache_mib_per_full_core":plan.core_size**2*min(cfg.top_m,len(views)*len(psi))*8/1024**2}
                else:
                    tiles = len(axis_offsets(h, cfg.window_size, cfg.overlap)) * len(axis_offsets(w, cfg.window_size, cfg.overlap))
                    job = {}
                job.update(path=str(rec.path),shape=data.shape,pixel_size=rec.pixel_size,tiles=tiles,
                           correlation_passes=1 if cfg.search_mode=="topk" else 2,
                           correlation_images=(1 if cfg.search_mode=="topk" else 2)*tiles*len(views)*len(psi))
                report["jobs"].append(job)
            report.update(search_mode=cfg.search_mode,score_processing=cfg.score_processing,
                          cache_template_conjugate=cfg.cache_template_conjugate,topk_skip_unchanged=cfg.topk_skip_unchanged,
                          topk_detailed_timing=cfg.topk_detailed_timing,top_m=cfg.top_m,padding_mode=cfg.padding_mode,
                          fft_size_mode=cfg.fft_size_mode,dedup_mode=cfg.dedup_mode,timing=cfg.timing)
            report.update(inverse_fft_detailed_timing=cfg.inverse_fft_detailed_timing,fft_profile_calls=cfg.fft_profile_calls,
                          cistem_peak_picking=cfg.cistem_peak_picking,cistem_peak_threshold=cfg.cistem_peak_threshold,
                          cistem_peak_radius_angstrom=cfg.cistem_peak_radius_angstrom,cistem_maximum_peaks=cfg.cistem_maximum_peaks)
            print(json.dumps(report, indent=2))
        else:
            report = run(cfg, log=lambda message: print(message, flush=True))
            print(f"Completed in {report['elapsed_seconds']:.1f} seconds: {cfg.output_dir}")
        return 0
    except Exception as exc:
        if args.debug:
            raise
        print(f"Error: {exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
