"""Preserve the native irfft2 path; optionally trace a bounded initial window."""
from contextlib import nullcontext
from pathlib import Path
import torch


class InverseFFTDiagnostics:
    def __init__(self,device,directory,detailed=True,profile_calls=0):
        self.device = torch.device(device)
        self.directory = Path(directory)
        self.detailed,self.profile_calls = detailed,profile_calls
        self.calls,self.layouts = 0,{}
        self.profiler = None
        self.profile_finished = False
        self.profiled_calls = 0

    def inverse(self,product,size,timer):
        signature = (tuple(product.shape),tuple(product.stride()),str(product.dtype),size)
        first = signature not in self.layouts
        if first:
            self.layouts[signature] = dict(input_shape=list(product.shape),input_stride=list(product.stride()),
                input_contiguous=product.is_contiguous(),input_conjugate_view=product.is_conj(),
                input_dtype=str(product.dtype),input_bytes=product.numel()*product.element_size(),
                output_shape=[*product.shape[:-2],size,size],output_bytes=product.shape[0]*size*size*(product.element_size()//2),
                norm="forward",calls=0)
        layout = self.layouts[signature]
        layout['calls'] += 1
        self.calls += 1
        tracing = self.calls <= self.profile_calls
        if tracing and self.profiler is None:
            activities = [torch.profiler.ProfilerActivity.CPU]
            if self.device.type == 'cuda':
                activities.append(torch.profiler.ProfilerActivity.CUDA)
            self.profiler = torch.profiler.profile(activities=activities,record_shapes=True,profile_memory=True)
            self.profiler.__enter__()
        phase = 'first_shape' if first else 'repeat_shape'
        with timer.section('correlation.inverse_fft.'+phase) if self.detailed else nullcontext():
            with torch.profiler.record_function('gisspa.correlation.irfft2') if tracing else nullcontext():
                full = torch.fft.irfft2(product,s=(size,size),norm='forward')
        if first:
            layout.update(output_stride=list(full.stride()),output_contiguous=full.is_contiguous(),output_dtype=str(full.dtype))
        if tracing:
            self.profiled_calls += 1
            if self.calls == self.profile_calls:
                self.close()
        return full

    def close(self):
        if self.profiler is None or self.profile_finished:
            return
        self.profiler.__exit__(None,None,None)
        self.profile_finished = True
        self.directory.mkdir(parents=True,exist_ok=True)
        self.profiler.export_chrome_trace(str(self.directory/'inverse_fft_profile.json'))
        summary = self.profiler.key_averages(group_by_input_shape=True)
        text = ('Bounded initial trace window. Filter gisspa.correlation.irfft2 in the Chrome trace.\n'
                'Intervening operations are recorded too. First calls can include plan initialization.\n'
                'Profiling changes timings; do not compare this run as steady-state throughput.\n\n')
        text += summary.table(sort_by='self_cpu_time_total',row_limit=80)
        if self.device.type == 'cuda':
            text += '\n\n'+summary.table(sort_by='self_device_time_total',row_limit=80)
        (self.directory/'inverse_fft_profile.txt').write_text(text,encoding='utf-8')
        self.profiler = None

    def report(self):
        self.close()
        return dict(calls=self.calls,detailed=self.detailed,layouts=list(self.layouts.values()),
                    profile_calls_requested=self.profile_calls,profiled_calls=self.profiled_calls,
                    trace_file='inverse_fft_profile.json' if self.profile_finished else None,
                    notes='first_shape means first occurrence in this matcher, not guaranteed cuFFT cache miss. '
                          'Native irfft2 is unchanged. CUDA events cover stream time including backend allocation/copy/FFT work. '
                          'Use the optional profiler to inspect backend operators and GPU kernels; no synthetic split is reported.')
