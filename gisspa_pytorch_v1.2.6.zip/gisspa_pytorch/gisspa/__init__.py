"""GisSPA norm_type=1 in PyTorch. See LICENSE."""
__version__ = "1.2.6"
