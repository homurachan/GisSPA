from __future__ import annotations

import json
from pathlib import Path
import numpy as np
import torch

from .config import Config
from .geometry import cisTEM_rotation_matrix
from .projector import FourierProjector
from .filters import ctf_image
from .star import Micrograph, write_star, OPTICS_COLUMNS, optics_row
from .mrcio import write_mrc


@torch.inference_mode()
def make_demo(directory):
    directory = Path(directory).resolve()
    if directory.exists() and any(directory.iterdir()):
        raise ValueError(f"demo directory must be new or empty: {directory}")
    directory.mkdir(parents=True, exist_ok=True)
    torch.set_num_threads(2)
    n, pixel = 32, 2.0
    zz, yy, xx = torch.meshgrid(*(torch.arange(n) - n // 2 for _ in range(3)), indexing="ij")
    volume = torch.zeros((n, n, n))
    for x, y, z, sigma, height in [(-5, -3, 2, 2.0, 1.0), (5, -1, -4, 1.5, 1.4),
                                  (0, 6, 4, 2.3, 0.8), (-2, 2, -6, 1.1, 1.7)]:
        volume += height * torch.exp(-((xx - x).square() + (yy - y).square() + (zz - z).square()) / (2 * sigma ** 2))
    write_mrc(directory / "template.mrc", volume, pixel)
    record = Micrograph("micrograph.mrc", directory / "micrograph.mrc", pixel, 300, 2.7, 0.07,
                        8000, 8000, 0)
    projector = FourierProjector(volume)
    targets = [(48, 48, 37, 63, 30), (112, 80, 100, 45, 120)]
    rng = np.random.default_rng(731)
    image = torch.from_numpy(rng.normal(0, 1, (128, 160)).astype(np.float32))
    for x, y, phi, theta, psi in targets:
        matrix = cisTEM_rotation_matrix(phi, theta, psi)
        projection = projector.project(matrix)[0]
        spectrum = torch.fft.rfft2(projection, norm="forward") * ctf_image((n, n), record, torch.device("cpu"))
        particle = torch.fft.irfft2(spectrum, s=(n, n), norm="forward")
        particle = 5 * particle / particle.std()
        image[y - n // 2:y + n // 2, x - n // 2:x + n // 2] += particle
    write_mrc(record.path, image, pixel)
    columns = ["_rlnMicrographName", "_rlnOpticsGroup", "_rlnDefocusU", "_rlnDefocusV", "_rlnDefocusAngle"]
    write_star(directory / "micrographs.star", [("optics", OPTICS_COLUMNS, [optics_row(record)]),
        ("micrographs", columns, [dict(zip(columns, ["micrograph.mrc", "1", 8000, 8000, 0]))])])
    (directory / "views.txt").write_text("# cisTEM phi theta\n37 63\n100 45\n0 0\n60 90\n", encoding="utf-8")
    cfg = Config(input_star="micrographs.star", template_mrc="template.mrc", orientations_file="views.txt",
                 output_dir="results", pixel_size=pixel, window_size=64, overlap=32, diameter=16,
                 psi_step=30, high_resolution=6, low_resolution=80, phase_flip=True,
                 threshold=3.25, orientation_batch_size=4, device="cpu", write_lst=True,
                 extract_box_size=32, dedup_distance=12, dedup_angle=180, dedup_allow_180=False)
    path = directory / "config.json"
    path.write_text(json.dumps(cfg.to_dict(), indent=2), encoding="utf-8")
    (directory / "ground_truth.json").write_text(json.dumps({"seed": 731, "description": "illustrative synthetic data; not an experimental benchmark",
        "particles": [dict(zip(("x", "y", "phi", "theta", "psi"), row)) for row in targets]}, indent=2), encoding="utf-8")
    return path
