"""One correlation pass with per-pixel Top-M and selectable boundary handling."""
import json
import math
import tempfile
import time
from pathlib import Path
import numpy as np
import torch
from .boundary import plan_boundary,prepare_padded_image,read_tile
from .runtime import TemplateRotator,SpectrumBank,available_device_bytes
from .topk import TopScores,TopWorkspace,CandidateTable,sparse_group_peaks,topk_stage
from .mrcio import read_mrc,write_mrc
from .fft_diagnostics import InverseFFTDiagnostics
from .peaks import peaks_from_maps,automatic_threshold_info,split_threshold_candidates


class CoreCrop:
    """Reusable flattened gather indices for one full or partial core shape."""
    def __init__(self,fft_size,core_offset,h,w,device):
        iy = (torch.arange(h,device=device)+core_offset+fft_size//2)%fft_size
        ix = (torch.arange(w,device=device)+core_offset+fft_size//2)%fft_size
        self.index = (iy[:,None]*fft_size+ix[None,:]).reshape(-1)


def core_correlation(image_f,template_f,fft_size,core_offset,h,w,timer,crop=None,out=None,contiguous=False,template_is_conjugated=False,fft_diagnostics=None):
    with timer.section("correlation.multiply"):
        product = image_f*(template_f if template_is_conjugated else template_f.conj())
    with timer.section("correlation.inverse_fft"):
        full = (torch.fft.irfft2(product,s=(fft_size,fft_size),norm="forward") if fft_diagnostics is None
                else fft_diagnostics.inverse(product,fft_size,timer))
    with timer.section("correlation.crop_core"):
        if crop is None:
            crop = CoreCrop(fft_size,core_offset,h,w,full.device)
        if contiguous:
            if out is None or not out.is_contiguous() or out.shape != (len(full),h*w):
                raise ValueError("contiguous crop requires a packed B x P output buffer")
            torch.index_select(full.flatten(1),1,crop.index,out=out)
            out.mul_(fft_size*fft_size)
            return out
        if out is None:
            values = torch.index_select(full.flatten(1).T,0,crop.index)
            values.mul_(fft_size*fft_size)
            return values.T.reshape(len(full),h,w)
        # P x B scores go directly into the shared Top-M merge buffer. No
        # separate B x H x W crop, transpose-copy, concatenation or scaled array.
        torch.index_select(full.flatten(1).T,0,crop.index,out=out)
        out.mul_(fft_size*fft_size)
        return out


@torch.inference_mode()
def match_topk(cfg,record,views,psi_values,device,job_dir,log,timer):
    from .engine import Moments,build_template_bank
    start = time.perf_counter()
    with timer.section("image.read_mrc",gpu=False):
        original,_ = read_mrc(record.path,record.pixel_size,image_slice=record.image_slice)
    plan = plan_boundary(original.shape,cfg)
    with timer.section("image.prepare_total"):
        padded = prepare_padded_image(torch.from_numpy(original).to(device),record,cfg,plan,timer)
    count = len(views)*len(psi_values)
    auto_info = automatic_threshold_info(int(original.size),count)
    candidate_threshold = min(cfg.threshold,auto_info['threshold'])
    if count >= 2**31:
        raise ValueError("orientation count exceeds int32 Top-M identifiers")
    m = min(cfg.top_m,count)
    log(f"Full-image Top-{m}: boundary={plan.mode}; {len(plan.offsets)} cores; core={plan.core_size}, halo={plan.halo}, core_offset={plan.core_offset}, FFT={plan.fft_size}; one pass")
    log(f"Artificial padding: {plan.padded_shape}, mode={cfg.padding_mode}; noise power estimated from original pixels")
    if plan.mode == "micrograph":
        log("Fixed windows use cyclic correlation. Whole-image padding does not guarantee removal of internal tile seams or wrap peaks; use boundary_mode=template_halo for full template neighborhoods.")
    maps = {name:np.zeros(original.shape,np.float32) for name in ("score","rot","tilt","psi","top_m_cutoff")}
    blocks = []
    cutoff_count,zero_variance,nonfinite_count = 0,0,0
    auto_cutoff_count = 0
    fft_diagnostics = InverseFFTDiagnostics(device,job_dir,cfg.inverse_fft_detailed_timing,cfg.fft_profile_calls)
    conjugate_batches = 0
    skip_counts = dict(pixel_updates=0,bounds_checked=0,selected=0,skipped=0,
                       all_skipped_batches=0,partial_batches=0)
    table_views = np.asarray(views)
    table_psi = np.asarray(psi_values)
    rotator = TemplateRotator(cfg.window_size,cfg,device)
    last_update = time.monotonic()
    performance = {"search_mode":"topk","correlation_passes":1,"views":len(views),"psi_positions":len(psi_values),
                   "total_orientations":count,"top_m_requested":cfg.top_m,"top_m_effective":m,
                   "tile_count":len(plan.offsets),"statistics_precision":cfg.statistics_precision,
                   "boundary":plan.to_dict(),"full_image_search":True,
                   "full_template_neighborhoods":plan.mode=="template_halo",
                   "score_processing":cfg.score_processing,
                   "cache_template_conjugate":cfg.cache_template_conjugate,
                   "topk_detailed_timing":cfg.topk_detailed_timing,
                   "topk_gate_before_full_copy":True,"topk_cutoff_cached":True,
                   "cutoff_cache_bytes_per_full_tile":plan.core_size**2*4,
                   "candidate_rule":"per pose, maximum among retained Top-M entries in each 1024-pixel core group"}
    with tempfile.TemporaryDirectory(prefix=".gisspa-cache-",dir=job_dir) as cache:
        with timer.section("template.base_bank_total"):
            path = build_template_bank(cfg,record,views,device,cache,log,timer=timer)
        with timer.section("template.cache_initialize"):
            bank = SpectrumBank(path,cfg,device,log)
        del path
        try:
            per_tile = plan.core_size**2*(4+8*m+(32 if cfg.statistics_precision=="mixed" else 48))+plan.fft_size**2*8
            available = available_device_bytes(device)
            work = cfg.orientation_batch_size*plan.fft_size**2*28+plan.core_size**2*(m+cfg.orientation_batch_size)*20
            extra = 0
            if cfg.score_processing != "direct":
                extra = plan.core_size**2*cfg.orientation_batch_size*4
                if cfg.score_processing == "contiguous_scratch":
                    extra += plan.core_size**2*cfg.orientation_batch_size*(4 if cfg.statistics_precision=="mixed" else 8)
            work += extra
            skip_extra = (plan.core_size**2*((m+cfg.orientation_batch_size)*4+m*8+9)
                          if cfg.topk_skip_unchanged else 0)
            work += skip_extra
            automatic = max(1,int(max(0,available*.8-work)//per_tile))
            group = min(len(plan.offsets),cfg.tile_group_size or automatic)
            performance.update(template_cache=bank.mode,template_cache_build=bank.build_storage,
                               tile_group_size=group,estimated_bytes_per_tile=per_tile,
                               estimated_batch_workspace_bytes=work)
            workspace = TopWorkspace(plan.core_size**2,m,cfg.orientation_batch_size,device,cfg.statistics_precision,
                                     cfg.score_processing,cfg.topk_skip_unchanged)
            crops = {}
            for y,x in plan.offsets:
                shape = (min(plan.core_size,original.shape[0]-y),min(plan.core_size,original.shape[1]-x))
                if shape not in crops:
                    crops[shape] = CoreCrop(plan.fft_size,plan.core_offset,*shape,device)
            performance.update(topk_workspace_bytes=workspace.nbytes,crop_plan_count=len(crops),
                               topk_merge="shared_pixel_major_buffer",additional_contiguous_workspace_bytes=extra,
                               additional_skip_workspace_bytes=skip_extra,
                               statistics_squares={"direct":"reuse_after_topk","contiguous":"contiguous_inplace",
                                                   "contiguous_scratch":"contiguous_separate_buffer"}[cfg.score_processing])
            log(f"Score processing: {cfg.score_processing}; shared workspace {workspace.nbytes/1024**2:.1f} MiB")
            log(f"Conjugate reuse={cfg.cache_template_conjugate}; Top-M skip experiment={cfg.topk_skip_unchanged}; detailed Top-M timing={cfg.topk_detailed_timing}")
            log(f"Template reuse: {group} cores per group; estimated tile state {per_tile/1024**2:.1f} MiB")
            for begin in range(0,len(plan.offsets),group):
                states = []
                with timer.section("tile.read_and_fft"):
                    for tid in range(begin,min(begin+group,len(plan.offsets))):
                        y,x = plan.offsets[tid]
                        tile,h,w = read_tile(padded,plan,y,x)
                        states.append({"id":tid,"y":y,"x":x,"h":h,"w":w,
                                       "f":torch.fft.rfft2(tile,norm="forward"),
                                       "moments":Moments((h,w),device,cfg.statistics_precision),
                                       "top":TopScores((h,w),m,device)})
                del tile
                for pi,psi in enumerate(psi_values):
                    with timer.section("template.rotation_plan"):
                        rotator.set_angle(psi)
                    for vs in range(0,len(views),cfg.orientation_batch_size):
                        ve = min(len(views),vs+cfg.orientation_batch_size)
                        with timer.section("template.cache_load"):
                            base = bank.get(vs,ve)
                        templates = rotator.prepare(base,plan.fft_size,timer)
                        if cfg.cache_template_conjugate:
                            with timer.section("template.prepare_conjugate"):
                                # prepare() returns a fresh FFT output, not a base-bank view.
                                # Materialize once, in place, before reusing across tiles.
                                templates.conj_physical_()
                            conjugate_batches += 1
                        ids = torch.arange(pi*len(views)+vs,pi*len(views)+ve,device=device,dtype=torch.int32)
                        for state in states:
                            shape = (state["h"],state["w"])
                            pixels,batch = shape[0]*shape[1],ve-vs
                            packed = cfg.score_processing != "direct"
                            cc = (workspace.contiguous_scores(pixels,batch) if packed
                                  else workspace.incoming(pixels,batch))
                            core_correlation(state["f"],templates,plan.fft_size,plan.core_offset,*shape,timer,
                                             crop=crops[shape],out=cc,contiguous=packed,
                                             template_is_conjugated=cfg.cache_template_conjugate,fft_diagnostics=fft_diagnostics)
                            with timer.section("topk.update"):
                                state["top"].select(workspace,ids,timer,cfg.topk_detailed_timing,cfg.topk_skip_unchanged,
                                                    incoming_scores=cc if packed else None)
                            with timer.section("statistics.accumulate_all"):
                                if packed:
                                    state["moments"].add_contiguous(cc,workspace,cfg.score_processing=="contiguous_scratch")
                                else:
                                    state["moments"].add_pixels(cc,workspace)
                            del cc
                        if time.monotonic()-last_update>20:
                            log(f"Core group {begin+1}-{begin+len(states)}/{len(plan.offsets)}; psi={psi:g}, views={ve}/{len(views)}")
                            last_update = time.monotonic()
                        del templates
                for state in states:
                    for key,value in state["top"].skip_counts.items():
                        skip_counts[key] += value
                    with timer.section("statistics.finalize_and_score"):
                        mean,std = state["moments"].finish()
                        if not bool(torch.isfinite(mean).all()&torch.isfinite(std).all()):
                            raise ValueError("nonfinite correlation moments")
                        scores = state["top"].scores(mean,std)
                        nonfinite_count += int((~torch.isfinite(scores)).sum().item())
                        if nonfinite_count:
                            raise ValueError("nonfinite final Top-M score")
                        zero_variance += int((std<=0).sum().item())
                        values,rank = scores.max(1)
                        best_ids = state["top"].ids.gather(1,rank[:,None]).squeeze(1)
                        cutoff = scores.min(1).values
                        if m<count:
                            cutoff_count += int((cutoff>=cfg.threshold).sum().item())
                            auto_cutoff_count += int((cutoff>=auto_info['threshold']).sum().item())
                    with timer.section("candidates.sparse_group_peaks"):
                        found = sparse_group_peaks(scores,state["top"].ids,(state["h"],state["w"]),plan.core_size,candidate_threshold)
                    with timer.section("candidates.transfer"):
                        rows = found.cpu().numpy()
                        if len(rows):
                            rows[:,0] += state["x"]
                            rows[:,1] += state["y"]
                            blocks.append(np.column_stack((rows,np.full(len(rows),state["id"]))))
                    if cfg.write_maps or cfg.cistem_peak_picking:
                        with timer.section("maps.transfer_and_assemble"):
                            h,w,y,x = state["h"],state["w"],state["y"],state["x"]
                            v = values.reshape(h,w).cpu().numpy()
                            bid = best_ids.reshape(h,w).cpu().numpy()
                            region = np.s_[y:y+h,x:x+w]
                            maps["score"][region] = v
                            maps["rot"][region] = table_views[bid%len(views),0]
                            maps["tilt"][region] = table_views[bid%len(views),1]
                            maps["psi"][region] = table_psi[bid//len(views)]
                            maps["top_m_cutoff"][region] = cutoff.reshape(h,w).cpu().numpy()
                del states,state,scores
                timer.flush()
                log(f"Completed cores {begin+1}-{min(begin+group,len(plan.offsets))}/{len(plan.offsets)}")
            performance.update(prepared_template_batches=rotator.prepared_batches,rotation_plan_builds=rotator.plan_builds,
                               template_batch_loads=bank.loads,correlation_images=len(plan.offsets)*count,
                               template_conjugate_materializations=conjugate_batches)
            del workspace,crops
        finally:
            fft_diagnostics.close()
            bank.close()
    with timer.section("candidates.pack",gpu=False):
        rows = np.concatenate(blocks) if blocks else np.empty((0,5))
        # Stable canonical order independent of batch and tile-group sizes.
        if len(rows):
            order = np.lexsort((rows[:,0],rows[:,1],rows[:,2],rows[:,4]))
            rows = rows[order]
        table = CandidateTable(rows,views,psi_values)
        table = split_threshold_candidates(table,cfg.threshold,auto_info)
    performance['auto_threshold'] = dict(
        auto_info, raw_candidates=len(table.auto_candidates),
        top_m_potentially_truncated_pixels=auto_cutoff_count,
        top_m_potentially_truncated_fraction=auto_cutoff_count/original.size,
        all_threshold_crossings_retained=(auto_cutoff_count==0))
    if cfg.write_maps:
        with timer.section("maps.write_mrc",gpu=False):
            for name,array in maps.items():
                filename = "top_m_cutoff.mrc" if name=="top_m_cutoff" else f"best_{name}.mrc"
                write_mrc(Path(job_dir)/filename,array,record.pixel_size)
            write_mrc(Path(job_dir)/"valid_search_mask.mrc",np.ones(original.shape,np.float32),record.pixel_size)
    if cfg.cistem_peak_picking:
        table.cistem_peaks,table.cistem_peak_info = peaks_from_maps(maps,cfg,record,timer)
        performance["cistem_peaks"] = table.cistem_peak_info
    performance["inverse_fft_diagnostics"] = fft_diagnostics.report()
    performance.update(top_m_potentially_truncated_pixels=cutoff_count,top_m_potentially_truncated_fraction=cutoff_count/original.size,
                       all_threshold_crossings_retained=(cutoff_count==0),zero_variance_pixels=zero_variance,
                       raw_candidates=len(table),elapsed_match_seconds=time.perf_counter()-start)
    performance["topk_skip"] = dict(enabled=cfg.topk_skip_unchanged,**skip_counts,
                                    skipped_fraction=skip_counts["skipped"]/max(1,skip_counts["pixel_updates"]),
                                    rule="skip only if batch maximum is strictly below historical Top-M minimum; statistics always include every pose")
    if cfg.topk_skip_unchanged:
        log(f"Top-M skipped {skip_counts['skipped']}/{skip_counts['pixel_updates']} pixel-batch updates ({performance['topk_skip']['skipped_fraction']:.2%}); all-orientation statistics retained")
    Path(job_dir,"performance.json").write_text(json.dumps(performance,indent=2),encoding="utf-8")
    log(f"Top-M cutoff >= threshold at {cutoff_count}/{original.size} pixels; retained candidates={len(table)}")
    return table,original
