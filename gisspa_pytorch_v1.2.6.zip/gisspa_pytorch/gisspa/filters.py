"""GisSPA GPU_func.cu filters, normalization and CTF, expressed as tensor operations."""
from __future__ import annotations

import math
import torch


def frequency_grid(shape, device, dtype=torch.float32):
    h, w = shape
    fy = torch.fft.fftfreq(h, device=device, dtype=dtype)
    fx = torch.fft.rfftfreq(w, device=device, dtype=dtype)
    yy, xx = torch.meshgrid(fy, fx, indexing="ij")
    radius = torch.hypot(xx * w, yy * h)
    bins = torch.floor(radius + 0.5).long() - 1
    valid = (bins >= 0) & (bins < max(h, w) // 2)
    return xx, yy, radius, bins, valid


def ctf_image(shape, record, device):
    xx, yy, _, _, _ = frequency_grid(shape, device)
    spatial2 = (xx.square() + yy.square()) / record.pixel_size ** 2
    # Source uses pixel-frequency indices for the astigmatism azimuth, even
    # for rectangular micrographs. Preserve that behavior instead of silently
    # replacing it with atan2(fy, fx) on normalized physical frequencies.
    azimuth = torch.atan2(yy * shape[0], xx * shape[1])
    angle = math.radians(record.defocus_angle)
    defocus = 0.5 * (record.defocus_u + record.defocus_v +
                     (record.defocus_u - record.defocus_v) * torch.cos(2 * (angle - azimuth)))
    wavelength = 12.2639 / math.sqrt(record.voltage * 1000 + 0.97845 * record.voltage ** 2)
    gamma = (math.pi * wavelength * defocus * spatial2 -
             0.5 * math.pi * record.cs * 1e7 * wavelength ** 3 * spatial2.square() +
             math.radians(record.phase_shift))
    amp = record.amplitude_contrast
    # Preserve GisSPA's CTF sign; the cisTEM reference's evaluate() has the opposite sign.
    return math.sqrt(1 - amp ** 2) * torch.sin(gamma) + amp * torch.cos(gamma)


def whiten(spectra, shape):
    h, w = shape
    _, _, _, bins, valid = frequency_grid(shape, spectra.device, spectra.real.dtype)
    nbin = max(h, w) // 2
    leading = spectra.shape[:-2]
    flat = spectra.reshape(-1, h * (w // 2 + 1))
    idx = valid.flatten().nonzero().flatten()
    rb = bins.flatten()[idx]
    counts = torch.bincount(rb, minlength=nbin).to(spectra.real.dtype)
    sums = torch.zeros((flat.shape[0], nbin), device=spectra.device, dtype=spectra.real.dtype)
    values = flat[:, idx].abs().square()
    sums.scatter_add_(1, rb[None].expand(flat.shape[0], -1), values)
    power = sums / counts.clamp_min(1)
    weights = torch.where(power > 0, power.clamp_min(1e-30).rsqrt(), 0)
    out = flat.clone()
    out[:, idx] *= weights[:, rb]
    return out.reshape(*leading, h, w // 2 + 1)


def bandpass(shape, pixel, cfg, device, *, template=False):
    _, _, _, bins, _ = frequency_grid(shape, device)
    r = bins.float()
    l = max(shape)
    hi = l * pixel / cfg.high_resolution
    lo = l * pixel / cfg.low_resolution
    # Preserve source branch order: template's first branch includes all low frequencies.
    passed = (r < hi) & (r >= (0 if template else lo))
    upper = (r >= hi) & (r < hi + 8)
    lower = (r >= lo - 8) & (r < lo) & (r >= 0)
    out = torch.zeros_like(r)
    out = torch.where(passed, 1, out)
    out = torch.where((~passed) & upper, 0.5 * torch.cos(math.pi * (r - hi) / 16) + 0.5, out)
    out = torch.where((~passed) & (~upper) & lower, 0.5 * torch.cos(math.pi * (lo - r) / 16) + 0.5, out)
    return out


def frequency_weight(shape, record, cfg, device, *, template=False):
    xx, yy, _, bins, valid = frequency_grid(shape, device)
    frequency = torch.sqrt(xx.square() + yy.square()) / record.pixel_size
    v = ctf_image(shape, record, device).abs()
    # Evaluate ratio in float64 to avoid unnecessary exp() overflow in finite inputs.
    s = frequency.double()
    log_ratio = ((cfg.a - cfg.bfactor) * s.square() + (cfg.b - cfg.bfactor2) * s +
                 cfg.b2 - cfg.bfactor3)
    if (log_ratio.abs() > 700).any():
        raise ValueError("SNR exponent outside supported numeric range; check coefficients and pixel size")
    ratio = torch.exp(log_ratio)
    denominator = ((cfg.kk + 1) * ratio + cfg.kk * v.double().square()).clamp_min(1e-300)
    if template:
        weights = v.double() / torch.sqrt(denominator)
    else:
        weights = torch.sqrt((v.double().square() + ratio) / denominator)
        # The repository tests rounded radius, not frequency > 1/6, on rectangular images too.
        damp = bins > max(shape) * record.pixel_size / 6
        weights *= torch.where(damp, torch.exp(-100 * frequency.square()), 1)
    weights = torch.where(valid, weights, 1).float()
    weights *= bandpass(shape, record.pixel_size, cfg, device, template=template)
    if not torch.isfinite(weights).all():
        raise ValueError("non-finite frequency weights")
    return weights


def spectral_normalize(spectra, shape):
    _, _, _, _, valid = frequency_grid(shape, spectra.device, spectra.real.dtype)
    count = valid.sum()
    energy = spectra[..., valid].abs().square().sum(-1)
    divisor = torch.sqrt(energy / count.square().clamp_min(1))
    divisor = torch.where(divisor > 0, divisor, 1)
    return spectra / divisor[..., None, None]


def center_pad(images, n):
    h, w = images.shape[-2:]
    if h > n or w > n:
        raise ValueError(f"template {h}x{w} does not fit window_size={n}")
    out = images.new_zeros((*images.shape[:-2], n, n))
    y, x = (n - h) // 2, (n - w) // 2
    out[..., y:y + h, x:x + w] = images
    return out


def prepare_templates(images, record, cfg):
    n = cfg.window_size
    images = center_pad(images, n)
    axis = torch.arange(n, device=images.device, dtype=images.dtype) - n // 2
    rr = axis[:, None].square() + axis[None].square()
    r = n / 2 - 2
    annulus = (rr >= (r - 1) ** 2) & (rr <= (r + 1) ** 2)
    edge_mean = images[..., annulus].mean(-1)
    sigma = images.double().var(dim=(-2, -1), correction=0).sqrt().to(images.dtype)
    normalized = (images - edge_mean[:, None, None]) / sigma.clamp_min(1e-8)[:, None, None]
    images = torch.where((sigma >= 1e-8)[:, None, None], normalized, images)
    spectrum = torch.fft.rfft2(images, norm="forward")
    spectrum = whiten(spectrum, (n, n))
    spectrum *= frequency_weight((n, n), record, cfg, images.device, template=True)
    spectrum = spectral_normalize(spectrum, (n, n))
    return torch.fft.irfft2(spectrum, s=(n, n), norm="forward")


def template_mask(n, cfg, device, dtype=torch.float32):
    axis = torch.arange(n, device=device, dtype=dtype) - n // 2
    radius = torch.hypot(axis[:, None], axis[None])
    r = 0.75 * cfg.diameter
    return torch.where(radius < r, 1,
                       torch.where(radius <= r + 12, 0.5 * torch.cos(math.pi * (radius - r) / 12) + 0.5, 0))


def mask_and_normalize(images, cfg, mask=None):
    if mask is None:
        mask = template_mask(images.shape[-1], cfg, images.device, images.dtype)
    images = images * mask
    mean = images.mean(dim=(-2, -1), keepdim=True)
    variance = (images.square().mean(dim=(-2, -1), keepdim=True) - mean.square()).clamp_min(0)
    return (images - mean) / torch.where(variance > 0, variance.sqrt(), 1)


def prepare_image(image, record, cfg):
    variance, mean = torch.var_mean(image.to(torch.float64), correction=0)
    if not torch.isfinite(variance) or variance <= 0:
        raise ValueError("input micrograph has no finite positive variance")
    sigma = variance.sqrt()
    lo, hi = (mean - 6 * sigma).to(image.dtype), (mean + 6 * sigma).to(image.dtype)
    image = torch.where((image < lo) | (image > hi), mean.to(image.dtype), image)
    if cfg.invert:
        image = -image
    spectrum = torch.fft.rfft2(image, norm="forward")
    if cfg.phase_flip:
        ctf = ctf_image(image.shape, record, image.device)
        spectrum *= torch.where(ctf > 0, 1, -1)
        spectrum = whiten(spectrum, image.shape)
        spectrum *= frequency_weight(image.shape, record, cfg, image.device)
    spectrum[0, 0] = 0
    return torch.fft.irfft2(spectrum, s=image.shape, norm="forward")


def tile_fourier(image, cfg):
    f = torch.fft.rfft2(image, norm="forward")
    if cfg.phase_flip:
        f = spectral_normalize(f, image.shape)
    return f


def correlate(image_fourier, templates_fourier, n):
    # This matches the actual original kernel (image * conj(template)), not its reversed comment.
    product = image_fourier * templates_fourier.conj()
    cc = torch.fft.irfft2(product, s=(n, n), norm="forward")
    return torch.fft.fftshift(cc, dim=(-2, -1)) / (n * n)
