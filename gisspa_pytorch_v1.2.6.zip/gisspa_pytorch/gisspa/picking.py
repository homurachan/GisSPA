"""Score-ordered greedy NMS with spatial cells and batched PyTorch conflicts."""
import math
import numpy as np
import torch
from .geometry import cisTEM_rotation_matrix


def symmetry_operators(name,device):
    name = name.strip().upper()
    kind,order = name[0],int(name[1:])
    angles = torch.arange(order,device=device)* (360/order)
    rotations = cisTEM_rotation_matrix(angles,0,0,device=device)
    if kind == "D":
        flip = cisTEM_rotation_matrix(0,180,0,device=device)
        rotations = torch.cat((rotations,rotations@flip))
    return rotations


def suppress(table,cfg,device,timer,log=lambda _:None):
    if not len(table):
        return table,{"input":0,"kept":0,"mode":cfg.dedup_mode,"pair_evaluations":0}
    radius = cfg.dedup_distance or cfg.diameter/2
    rows = table.rows
    # Deterministic score -> y -> x -> pose -> source-row tie order.
    with timer.section("dedup.spatial_index",gpu=False):
        order = np.lexsort((np.arange(len(rows)),rows[:,2],rows[:,0],rows[:,1],-rows[:,3]))
        data = rows[order]
        cells = np.floor(data[:,:2]/radius).astype(np.int64)
        width = int(cells[:,0].max())+2
        cellkeys = cells[:,1]*width+cells[:,0]
        cellorder = np.argsort(cellkeys,kind="stable")
        unique,starts,counts = np.unique(cellkeys[cellorder],return_index=True,return_counts=True)
        buckets = {int(k):(int(s),int(s+c)) for k,s,c in zip(unique,starts,counts)}
        deleted = np.zeros(len(data),dtype=bool)
    positions = torch.from_numpy(data[:,:2].astype(np.float32)).to(device)
    pose_ids = torch.from_numpy(data[:,2].astype(np.int64)).to(device)
    matrices = None
    with timer.section("dedup.orientation_matrices"):
        if cfg.dedup_mode == "pose":
            angles = torch.tensor([(a,b,p) for p in table.psi for a,b in table.views],device=device)
            matrices = cisTEM_rotation_matrix(*angles.unbind(1),device=device)
            symmetry = symmetry_operators(cfg.symmetry if cfg.dedup_use_symmetry else "C1",device)
    cos_limit = math.cos(math.radians(cfg.dedup_angle))
    pairs = 0

    def conflicts(a,b):
        nonlocal pairs
        a = torch.as_tensor(a,device=device,dtype=torch.long)
        b = torch.as_tensor(b,device=device,dtype=torch.long)
        pairs += len(a)*len(b)
        delta = positions[a,None,:]-positions[b][None,:,:]
        close = delta.square().sum(-1)<radius*radius
        if matrices is not None:
            ra,rb = matrices[pose_ids[a]],matrices[pose_ids[b]]
            angular = torch.zeros_like(close)
            for sym in symmetry:
                # Projector maps image Fourier coordinates to volume using R;
                # specimen symmetry therefore acts on the LEFT: S @ R.
                trace = (sym@ra).flatten(1)@rb.flatten(1).T
                cosine = ((trace-1)*.5).clamp(-1,1)
                angular |= cosine>cos_limit
                if cfg.dedup_allow_180:
                    angular |= cosine < -cos_limit
            close &= angular
        return close

    kept,begin,rounds = [],0,0
    while begin<len(data):
        end = min(len(data),begin+cfg.dedup_batch_size)
        active = np.flatnonzero(~deleted[begin:end])+begin
        if len(active):
            with timer.section("dedup.within_batch_conflicts"):
                conflict = conflicts(active,active).cpu().numpy()
            accepted = []
            blocked = np.zeros(len(active),bool)
            with timer.section("dedup.greedy_decisions",gpu=False):
                for i in range(len(active)):
                    if not blocked[i]:
                        accepted.append(int(active[i]))
                        blocked[i+1:] |= conflict[i,i+1:]
                kept.extend(accepted)
                keys = set()
                for i in accepted:
                    cx,cy = cells[i]
                    for dy in (-1,0,1):
                        for dx in (-1,0,1):
                            if 0<=cx+dx<width and cy+dy>=0:
                                keys.add(int((cy+dy)*width+cx+dx))
                parts = [cellorder[s:e] for key in keys if key in buckets for s,e in [buckets[key]]]
                neighbors = np.concatenate(parts) if parts else np.empty(0,np.int64)
                neighbors = neighbors[(neighbors>=end)&~deleted[neighbors]]
            for start in range(0,len(neighbors),cfg.dedup_chunk_size):
                subset = neighbors[start:start+cfg.dedup_chunk_size]
                with timer.section("dedup.neighbor_conflicts"):
                    remove = conflicts(accepted,subset).any(0).cpu().numpy()
                deleted[subset[remove]] = True
            rounds += 1
            if rounds%100 == 0:
                log(f"Deduplication: scanned {end}/{len(data)}, kept {len(kept)}")
        begin = end
    return table.take(order[np.asarray(kept,dtype=np.int64)]),{
        "mode":cfg.dedup_mode,"input":len(table),"kept":len(kept),"distance_pixels":radius,
        "angle_degrees":cfg.dedup_angle if cfg.dedup_mode=="pose" else None,
        "symmetry":cfg.symmetry if cfg.dedup_use_symmetry else "C1 (no folding)",
        "legacy_180_fold":cfg.dedup_allow_180,"pair_evaluations":pairs,"active_batches":rounds}
