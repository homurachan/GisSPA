# GisSPA PyTorch v1.2.6

基于用户提供的 `gisspa_pytorch_v1.2.5.1.zip` 修改的完整 Python 程序。
支持 3D MRC volume 投影、2D MRCS 模板、RELION STAR 输入输出及常驻多 GPU worker。
依赖为 **PyTorch、NumPy、mrcfile** 和 Python 标准库。

1.2.6 自动新增 `candidates_auto_threshold.star` 和 `picks_auto_threshold.star`，将原有 cisTEM 理论自动阈值用于 GisSPA 候选及去重流程。原有手动阈值输出继续保留。完整语义见 [更新说明](UPGRADE_1_2_6.md)。

## 安装与运行

需要 Python 3.10 以上。使用 GPU 时，请在已有可用 CUDA PyTorch 的环境中运行。
解压并进入本目录，可以直接运行：

```console
python -m pip install -r requirements.txt
python run_gisspa.py --version
python run_gisspa.py check gisspa_config.json --device cuda
python run_gisspa.py run gisspa_config.json --gpus 0,1,2,3 --topk-skip-unchanged --cache-template-conjugate --output-dir results_v1_2_6
```

若现有环境已经包含依赖，不必重复安装。也可以安装命令行入口：

```console
python -m pip install -e .
gisspa --version
gisspa run gisspa_config.json --gpus 0,1 --output-dir results_v1_2_6
```

`gisspa-torch` 与 `python -m gisspa` 也是同一程序入口。`--gpus all` 使用当前可见的所有 GPU；`--gpus` 与 `--device` 互斥。未指定 GPU 列表时使用单设备顺序处理。

保留了输入包的 `gisspa_config.json` 和 `default_config.json`；实际使用前请检查其中的数据路径和实验参数。配置中的相对路径以配置文件所在目录为基准，缺失字段使用默认值。

无需 GPU 的合成示例：

```console
python run_gisspa.py run example_data/config.json --device cpu
python run_gisspa.py demo --output my_demo --run
python -m unittest discover -s tests -v
```

## 输出

| 文件 | 内容 |
|---|---|
| 每图 `candidates.star` / `picks.star` | 原有手动阈值候选 / 按配置去重结果 |
| 每图 `candidates_auto_threshold.star` / `picks_auto_threshold.star` | 自动阈值候选 / 按相同配置独立去重结果 |
| 每图 `auto_threshold.json` | 本图实际自动阈值、搜索计数及结果数量 |
| `all_picks.star` | 原有手动阈值去重结果的批量合并 |
| `all_candidates_auto_threshold.star` / `all_picks_auto_threshold.star` | 新增自动阈值结果的批量合并 |
| 每图 `coordinates.star` | 原有手动阈值的 RELION 坐标输出 |
| `cistem_peaks.star` / `all_cistem_peaks.star` | 独立的 cisTEM 风格全图空间挑峰结果 |
| 每图 `cistem_peaks.json` | 独立挑峰的实际阈值、半径、数量上限 |
| 每图 `candidates.lst` | 配置 `write_lst=true` 时的原有候选输出 |
| 每图 `particles.star` / `particles.mrcs`、根目录 `all_particles.star` | 配置提取时的原有手动阈值粒子结果 |
| `best_score.mrc` / `best_rot.mrc` / `best_tilt.mrc` / `best_psi.mrc` | 原图尺寸的最佳分数与姿态图 |
| `top_m_cutoff.mrc` / `valid_search_mask.mrc` | Top-M 截断分数图 / 有效搜索区域 |
| `performance.json` / `deduplication.json` / `timing.json` / `timing.tsv` | 搜索、原有去重及性能诊断 |
| `summary.json` / `run_summary.json` | 每图及整个批次的运行摘要 |
| `inverse_fft_profile.json` / `.txt` | 启用 FFT profiling 时的诊断 |

新增文件无需额外开关；关闭独立 cisTEM 挑峰或分数图输出时仍然生成。`cistem_peak_threshold` 的手动覆盖、cisTEM 空间半径和峰值上限只作用于独立挑峰文件。粒子提取和原有坐标文件继续对应原有 `picks.star`。

## 搜索与边界

默认每像素保留 Top-M（M=16），只计算一遍相关；之后按姿态及 1024 像素分组取峰。自动阈值分支沿用同一候选规则，不能恢复已经被 Top-M 丢弃的姿态。

默认 `boundary_mode=micrograph` 使用整图人工补边和固定窗口循环相关，不保证消除内部 tile 接缝或环绕峰。需要完整模板邻域时使用 `boundary_mode=template_halo`。坐标和 CTF 单位约定保持输入版本不变。

1.2.6 的理论阈值使用原始图像像素数及全部搜索姿态数，沿用输入版本的高斯尾概率公式。分数仍是 GisSPA z-score，理论假阳性期望不是实测错误率。

## 验证

包含 9 项自动化回归测试及 21 组与输入版本的对照记录，见 [验证报告](VALIDATION_1_2_6.md)。当前验证环境为 CPU；未实测 CUDA、多 GPU 或实验数据性能。

程序沿用输入包的 [LICENSE](LICENSE)。`MANIFEST.json` 记录发布文件的 SHA-256（不包含该清单自身）。
