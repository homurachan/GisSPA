"""Regression tests for independent manual/automatic candidate branches."""
from dataclasses import replace
import json
import math
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

import numpy as np
import torch

from gisspa.batch import MERGED_FILES, run_batch
from gisspa.config import Config
from gisspa.engine import Pick, run
from gisspa.mrcio import write_mrc
from gisspa.peaks import (MatchPicks, automatic_threshold_info,
                          cistem_theoretical_threshold, peaks_from_maps,
                          split_threshold_candidates)
from gisspa.runtime import CandidateBuffer
from gisspa.star import read_star, Micrograph, write_star
from gisspa.topk import CandidateTable, sparse_group_peaks


def particles(path):
    return next(loop.rows for loop in read_star(path) if loop.block == 'particles')


def make_fixture(root):
    """An implanted matching template gives nonempty automatic-threshold picks."""
    rng = np.random.default_rng(2718)
    templates = rng.normal(size=(96, 32, 32)).astype(np.float32)
    image = rng.normal(scale=.1, size=(64, 64)).astype(np.float32)
    image[:32, :32] += templates[0] * 10
    write_mrc(root / 'templates.mrcs', templates, 2)
    write_mrc(root / 'micrograph.mrc', image, 2)
    (root / 'views.txt').write_text(''.join(f'{i * 3.75} 60\n' for i in range(96)), encoding='utf-8')
    return Config(input_mrc=str(root / 'micrograph.mrc'),
                  template_stack=str(root / 'templates.mrcs'),
                  orientations_file=str(root / 'views.txt'),
                  output_dir=str(root / 'results'), pixel_size=2,
                  window_size=32, overlap=0, diameter=24, psi_step=360,
                  defocus_u=0, defocus_v=0, threshold=20, device='cpu',
                  high_resolution=4, low_resolution=60, padding_mode='zero',
                  orientation_batch_size=16, cpu_threads=2, timing='off')


class ThresholdTests(unittest.TestCase):
    def test_gaussian_tail_and_all_search_trials(self):
        for pixels, poses in ((4096, 96), (100000000, 1000000)):
            info = automatic_threshold_info(pixels, poses)
            tail = .5 * math.erfc(info['threshold'] / math.sqrt(2))
            self.assertAlmostEqual(tail * pixels * poses, 1, places=11)
            self.assertEqual(info['effective_trials'], pixels * poses)
        self.assertGreater(cistem_theoretical_threshold(4096, 192),
                           cistem_theoretical_threshold(4096, 96))

    def test_shared_cistem_threshold_and_manual_override(self):
        cfg = Config(cistem_peak_threshold=None, cistem_maximum_peaks=0)
        maps = {key: np.zeros((8, 9), np.float32) for key in ('score', 'rot', 'tilt', 'psi')}
        record = Micrograph('image.mrc', Path('image.mrc'), 2, 300, 2.7, .07, 0, 0, 0)
        with patch('gisspa.engine.read_views', return_value=([(0, 0)] * 3, [0, 90])):
            _, info = peaks_from_maps(maps, cfg, record)
            self.assertEqual(info['threshold'], automatic_threshold_info(72, 6)['threshold'])
            _, override = peaks_from_maps(maps, replace(cfg, cistem_peak_threshold=2), record)
            self.assertEqual(override['threshold'], 2)
            self.assertEqual(override['threshold_source'], 'manual_override')

    def test_split_keeps_float32_boundary_and_order(self):
        value = np.float32(4.561197836079113)
        # A double cutoff just above this float32 score rounds back to it during matching.
        cutoff = float(value) + 1e-10
        below = np.nextafter(value, np.float32(-np.inf))
        rows = np.array([[9, 2, 0, value, 1], [1, 1, 1, below, 0], [8, 3, 0, 7, 1]])
        table = CandidateTable(rows, [(0, 0), (90, 60)], [0])
        for source in (table, MatchPicks(table)):
            selected = split_threshold_candidates(source, 8, {'threshold': cutoff})
            self.assertEqual(len(selected), 0)
            self.assertEqual([p.x for p in selected.auto_candidates], [9, 8])
            equal = split_threshold_candidates(source, cutoff, {'threshold': cutoff})
            self.assertEqual(list(equal), list(equal.auto_candidates))

    def test_topk_union_matches_direct_reduction(self):
        generator = torch.Generator().manual_seed(22)
        scores = torch.randn(2048, 4, generator=generator)
        scores[100:105] = 7  # ties and multiple 1024-pixel groups
        ids = torch.arange(4, dtype=torch.int32).expand(2048, -1)
        for manual, automatic in ((2, 5), (8, 5), (5, 5)):
            union = sparse_group_peaks(scores, ids, (32, 64), 64, min(manual, automatic))
            rows = np.column_stack((union.numpy(), np.zeros(len(union))))
            table = split_threshold_candidates(CandidateTable(rows, [(0, 0)] * 4, [0]),
                                               manual, {'threshold': automatic})
            for cutoff, selected in ((manual, table), (automatic, table.auto_candidates)):
                direct = sparse_group_peaks(scores, ids, (32, 64), 64, cutoff).numpy()
                np.testing.assert_array_equal(selected.rows[:, :4], direct)

    def test_legacy_buffer_collects_below_manual_and_rejects_padding(self):
        cfg = Config(threshold=8, window_size=32)
        raw = MatchPicks()
        buffer = CandidateBuffer(cfg, [(0, 0)], [(0, 0)], (16, 16), raw, Pick, threshold=5)
        buffer.add(torch.tensor([[6., 9., 10.]]), torch.tensor([[0, 1, 31]]), 0, 0, 0)
        buffer.flush()
        selected = split_threshold_candidates(raw, cfg.threshold, {'threshold': 5})
        self.assertEqual([p.score for p in selected], [9])
        self.assertEqual([p.score for p in selected.auto_candidates], [6, 9])
        self.assertEqual(cfg.threshold, 8)


class PipelineTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.root = Path(self.temporary.name)
        self.cfg = make_fixture(self.root)

    def tearDown(self):
        self.temporary.cleanup()

    def execute(self, label, **changes):
        cfg = replace(self.cfg, output_dir=str(self.root / label), **changes)
        report = run(cfg, log=lambda _: None)
        return cfg, report, Path(report['micrographs'][0]['output_directory'])

    def test_both_search_modes_all_dedup_modes_and_threshold_directions(self):
        for search in ('topk', 'legacy'):
            for mode in ('pose', 'spatial', 'legacy', 'disabled'):
                with self.subTest(search=search, dedup=mode):
                    options = dict(search_mode=search, dedup_mode='pose' if mode == 'disabled' else mode,
                                   deduplicate=mode != 'disabled', write_maps=False,
                                   cistem_peak_picking=False)
                    _, high_report, high = self.execute(f'{search}_{mode}_high', threshold=20, **options)
                    info = high_report['micrographs'][0]['auto_threshold']
                    self.assertEqual(particles(high / 'candidates.star'), [])
                    self.assertGreater(info['raw_candidates'], 0)
                    self.assertGreater(info['picks'], 0)
                    self.assertFalse((high / 'cistem_peaks.star').exists())
                    self.assertFalse((high / 'best_score.mrc').exists())
                    _, _, low = self.execute(f'{search}_{mode}_low', threshold=2.8, **options)
                    _, _, exact = self.execute(f'{search}_{mode}_exact', threshold=info['threshold'], **options)
                    for stem in ('candidates', 'picks'):
                        expected = (high / f'{stem}_auto_threshold.star').read_bytes()
                        self.assertEqual(expected, (low / f'{stem}_auto_threshold.star').read_bytes())
                        self.assertEqual(expected, (exact / f'{stem}.star').read_bytes())
                    self.assertEqual(info['number_of_valid_search_pixels'], 4096)
                    self.assertEqual(info['number_searched'], 96)

    def test_cistem_override_limit_and_auto_outputs_are_independent(self):
        _, default_report, default = self.execute('default')
        expected = default_report['micrographs'][0]['auto_threshold']['threshold']
        self.assertEqual(default_report['micrographs'][0]['cistem_peaks']['threshold'], expected)
        _, override_report, override = self.execute('override', cistem_peak_threshold=100,
                                                   cistem_maximum_peaks=0)
        self.assertEqual(particles(override / 'cistem_peaks.star'), [])
        self.assertEqual(override_report['micrographs'][0]['cistem_peaks']['threshold'], 100)
        for stem in ('candidates', 'picks'):
            self.assertEqual((default / f'{stem}_auto_threshold.star').read_bytes(),
                             (override / f'{stem}_auto_threshold.star').read_bytes())

    def test_multigraph_merge_optics_and_per_image_threshold(self):
        rng = np.random.default_rng(90)
        write_mrc(self.root / 'other.mrc', rng.normal(size=(70, 95)).astype(np.float32), 2)
        star = self.root / 'input.star'
        columns = ['_rlnMicrographName', '_rlnDefocusU', '_rlnDefocusV', '_rlnDefocusAngle']
        write_star(star, [('micrographs', columns, [dict(zip(columns, [name, 0, 0, 0]))
                                                   for name in ('micrograph.mrc', 'other.mrc')])])
        cfg, report, _ = self.execute('merged', input_mrc=None, input_star=str(star))
        infos = report['micrographs']
        self.assertEqual(len(infos), 2)
        self.assertLess(infos[0]['auto_threshold']['threshold'], infos[1]['auto_threshold']['threshold'])
        for stem in ('candidates', 'picks'):
            target = Path(cfg.output_dir) / f'all_{stem}_auto_threshold.star'
            loops = read_star(target)
            self.assertEqual(len(next(loop.rows for loop in loops if loop.block == 'optics')), 2)
            expected = []
            for i, info in enumerate(infos):
                for row in particles(Path(info['output_directory']) / f'{stem}_auto_threshold.star'):
                    row['_rlnOpticsGroup'] = str(i + 1)
                    expected.append(row)
            self.assertEqual(particles(target), expected)
        # Exercise the persistent spawned-worker path using CPU workers here;
        # this checks scheduling/output integration, not CUDA numerical behavior.
        with patch('gisspa.batch.resolve_worker_devices', return_value=['cpu', 'cpu']):
            worker_cfg, worker_report, _ = self.execute('merged_workers', input_mrc=None, input_star=str(star))
        self.assertEqual(worker_report['active_worker_count'], 2)
        for stem in ('candidates', 'picks'):
            filename = f'all_{stem}_auto_threshold.star'
            self.assertEqual((Path(cfg.output_dir) / filename).read_bytes(),
                             (Path(worker_cfg.output_dir) / filename).read_bytes())

    def test_overwrite_empty_results_and_failed_merge_cleanup(self):
        cfg, _, job = self.execute('overwrite')
        self.assertTrue(particles(job / 'picks_auto_threshold.star'))
        # Two searched poses bound standardized scores near one, below the cutoff.
        from gisspa.mrcio import read_mrc
        templates, _ = read_mrc(self.root / 'templates.mrcs', 2, stack=True)
        write_mrc(self.root / 'templates.mrcs', templates[:2], 2)
        (self.root / 'views.txt').write_text('0 60\n3.75 60\n', encoding='utf-8')
        run(replace(cfg, overwrite=True, cistem_peak_picking=False), log=lambda _: None)
        self.assertEqual(particles(job / 'picks_auto_threshold.star'), [])
        self.assertEqual(particles(Path(cfg.output_dir) / 'all_picks_auto_threshold.star'), [])
        self.assertFalse((job / 'cistem_peaks.star').exists())
        with patch('gisspa.batch.merge_outputs', side_effect=RuntimeError('simulated merge failure')):
            with self.assertRaisesRegex(RuntimeError, 'simulated merge failure'):
                run_batch(replace(cfg, overwrite=True), log=lambda _: None)
        for filename in MERGED_FILES:
            self.assertFalse((Path(cfg.output_dir) / filename).exists())
        summary = json.loads((Path(cfg.output_dir) / 'run_summary.json').read_text())
        self.assertEqual(summary['status'], 'failed')


if __name__ == '__main__':
    unittest.main()
