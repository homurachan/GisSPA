# GisSPA PyTorch 1.2.6 更新说明

此版本基于用户提供的 `gisspa_pytorch_v1.2.5.1.zip` 修改。该压缩包内的 Python 和安装元数据仍标记为 1.2.5，本次统一更新为 **1.2.6**。

## 新增输出

每张 micrograph 的结果目录自动新增：

| 文件 | 内容 |
|---|---|
| `candidates_auto_threshold.star` | 使用 cisTEM 理论自动阈值的候选，尚未去重 |
| `picks_auto_threshold.star` | 对上述候选按当前配置独立去重后的结果 |
| `auto_threshold.json` | 本图的阈值、搜索计数、候选数量、保留数量及去重参数 |

总结果目录新增 `all_candidates_auto_threshold.star` 和 `all_picks_auto_threshold.star`，按输入图像顺序合并并保持正确的 optics 分组。单设备与常驻 worker 使用同一输出流程。

## 阈值与算法

使用输入版本已有的 `cistem_theoretical_threshold()`，未改变公式：

```text
N_pixels = 原始 micrograph 的高 × 宽（不含人工 padding）
N_orientations = 搜索视角数量 × psi 位置数量
effective_trials = N_pixels × N_orientations
0.5 × erfc(threshold / sqrt(2)) = 1 / effective_trials
```

沿用 `expected_false_positives=1.0`、`independent_fraction=1.0`，按每张图分别计算，使用全部搜索姿态数量，不使用 Top-M 的 M 或通过阈值后的候选数。这是原有高斯模型下的理论阈值，不代表实测假阳性率；分数仍是 GisSPA z-score。

计算相关分数时，在 `min(threshold, 自动阈值)` 处收集候选，再分成手动和自动两路。因此当手动阈值更高时，自动结果仍包含低于手动阈值而通过自动阈值的候选。两路共享相关计算，不为此重复搜索。

候选和去重规则不变：Top-M 模式仍按保留的 Top-M 条目生成每姿态、每 1024 像素组的峰值；legacy 模式仍使用原来的分组峰值。自动候选独立执行当前 `deduplicate`、`dedup_mode`、距离、角度及对称性等设置。没有将 cisTEM 全图空间挑峰规则替换进这两个文件，也没有对已去重的手动结果简单再过滤。

Top-M 本身的截断仍然存在。`performance.json` 中保留原手动阈值诊断，并在 `auto_threshold` 下新增自动阈值对应的截断诊断。两路额外的候选保留、去重和文件输出可能增加内存、处理时间及磁盘使用量。

## 兼容性

- 原有 `candidates.star`、`picks.star`、`coordinates.star`、LST、粒子提取、分数图及原有批量合并结果继续按原配置生成。
- `threshold` 继续控制原有手动阈值结果。
- `cistem_peak_threshold=null` 时，`cistem_peaks.star` 与新增文件使用相同的理论自动阈值。
- 显式设置 `cistem_peak_threshold` 只覆盖 `cistem_peaks.star` 的阈值；新增的 `*_auto_threshold.star` 始终使用自动阈值。
- `cistem_peak_picking=false` 或 `write_maps=false` 不会关闭新增文件。
- cisTEM 独立挑峰的半径与数量上限只作用于 `cistem_peaks.star`，不限制新增文件。
- 不新增必填配置项，现有 JSON 配置可继续使用。新增文件即使没有候选也包含完整的 STAR 表头。
- 原始压缩包、原始数据及配置未被覆盖。

## 运行

解压并进入 `gisspa_pytorch` 目录，在已有 PyTorch、NumPy、mrcfile 环境中：

```console
python run_gisspa.py --version
python run_gisspa.py run gisspa_config.json --gpus 0,1,2,3 --topk-skip-unchanged --cache-template-conjugate --output-dir results_v1_2_6
```

也可执行 `python -m pip install -e .` 后使用 `gisspa` 或 `gisspa-torch` 命令。压缩包是与输入版本相同形式的完整 Python 程序，仍需要 Python 3.10+ 及依赖；未捆绑 Python、PyTorch 或 CUDA。另提供 1.2.6 wheel 安装包。

验证范围见 `VALIDATION_1_2_6.md`。
